<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `about`";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <div type="checkbox" id="day_night" class="day_night" onclick="day_night()">sun</div>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                if($users!="" && $rows){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    }
                }else{
                    echo "<a href='login.php'>请登录</a>";
                }
             ?> 
        </div>
    </div>
    <!-- body -->
    <div id="body">
        <!-- card -->
                 <?php
                    if($nr){
                    foreach($nr as $nrs) {
                        $id_s=$nrs['id'];//id
                        $user_s=$nrs['user'];//用户名
                        $biaoti_s=$nrs['biaoti'];//标题
                        $text_s=$nrs['text'];//描述
                        $about_user_img=$nrs['user_img'];//用户头像
                        $tp_s=$nrs['tp'];//上传的照片
                        $time_s=$nrs['time'];//上传时间
                        if($tp_s=="img/"){
                            echo"<div class='box'>
                                    <div>
                                        <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                        <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                    </div>
                                    <hr>
                                    <div>
                                    </div>
                                    <div>
                                        <span>发布者:{$user_s}</span>
                                        <hr>
                                        <span>发布时间:{$time_s}</span>
                                        <a href='going.php?text_id={$id_s}' class='flr'>详情-></a>
                                    </div>
                                </div>";
                        }else{
                           echo"<div class='box'>
                                    <div>
                                        <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                        <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                    </div>
                                    <hr>
                                    <div>
                                        <img src='{$tp_s}' alt='{$tp_s}' class='card_img'>
                                    </div>
                                    <hr>
                                    <div>
                                        <div>发布者:{$user_s}</span>&nbsp;&nbsp;&nbsp;</div>
                                        <hr>
                                        发布时间:{$time_s}</span>
                                        <a href='going.php?text_id={$id_s}' class='flr'>详情-></a>
                                    </div>
                                </div>";
                        }
                     
                    };
                }else{
                    echo "本站无数据，需要你们动动小手哟！";
                }
             ?> 
    </div>

    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 50px;">
        <p>------under line------</p>
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
    <!-- else -->
    <?php 
        if($users!="" && $row){
                foreach($rows as $row) {
                $user_img=$row['img'];
                echo
                "<div id='sumbit' onclick='o()'>+</div>
                    <div id='sumbit_all'>
                        <div id='sumbit_all_x' onclick='x()'>x</div>
                        <div id='sumbit_all_one'>
                            <form action='add.php' method='post' enctype='multipart/form-data'>
                                <hr>
                                <textarea placeholder='标题' class='textarea1' name='biaoti'></textarea>
                                <hr>
                                <textarea placeholder='内容' class='textarea2' name='text'></textarea>
                                <input type='text' name='user_img' id='user_img' value='{$user_img}' style='display:none;'>
                                <hr>
                                    <label for='index_img' class='top' id='label'>上传图片</label>
                                    <input type='file' name='tp' id='index_img' style='display:none;'>
                                 <button type='submit' class='loginbutton' onclick='tp()'>上传</button>
                            </form>
                        </div>
                </div>";
                }
        }else{echo "<div style='text-align: center;'>登录才能发贴哦！</div>";}
     ?>
     
</body>
    <script src="js/index.js"></script>
</html>