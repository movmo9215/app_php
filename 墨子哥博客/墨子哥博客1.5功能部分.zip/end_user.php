<?php 
include('conn.php');
// 获取数据库内容
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user`";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
//删除数据处理
$dele_id=$_GET['dele_id'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "DELETE FROM `user` WHERE `user`='{$dele_id}'";
        $code=$pdo->exec("$sql");
        if($code>0){
            echo "<script>alert('删除成功')</script>";
            echo"<script>window.location.replace('end_user.php');</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客|end_user</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="end_user.php">用户的信息</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                            echo "<a href='end_text.php'>发布的信息</a>";
                     ?>
                </li>
                <li>
                    <label class="zy" onclick="day_and_night()">
                        <input type="checkbox" class="checkbox" id="checkbox">
                    </label>    
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                         echo "NEXT";
             ?> 
        </div>
    </div>
    <!-- body -->
                 <?php
                    if($nr){
                    foreach($nr as $nrs) {
                        $user_s=$nrs['user'];//用户名
                        $pwd_s=$nrs['pwd'];//标题
                        $time_s=$nrs['time'];//上传时间
                        $img_s=$nrs['img'];//上传时间
                            echo"<div class='bigbox'>
                                    <div>
                                       <h3>用户名:{$user_s}</h3> 
                                    </div>
                                    <hr>
                                    <div>
                                        <h3>密码:{$pwd_s}</h3> 
                                    </div>
                                    <hr>
                                    <div>
                                        <h3>创建时间:{$time_s}</h3>  
                                    </div>
                                    <hr>
                                    <div>
                                        <h3>用户图片名称:{$img_s}</h3>
                                        <img src='{$img_s}' class='card_img'></img>      
                                    </div>
                                    <hr>
                                    <a href='#' onclick='end_user_dele(&quot;{$user_s}&quot;)' class='flr'>删除</a>
                                </div>";
                    }
                }else{
                    echo "<br><br><br><h1>无用户</h1>";
                }
             ?> 
    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 50px;">
        <p>------到底啦!------</p>
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
</body>
    <script src="js/index.js"></script>
</html>