<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li><a href="index.php">返回</a></li>
                <li>
                    <label class="zy" onclick="day_and_night()">
                        <input type="checkbox" class="checkbox" id="checkbox">
                    </label>    
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
           <?php 
                if($users!=""){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    };
                }else{
                     echo "请登录";
                }
             ?>
        </div>
    </div>
    <!-- body -->
    <div id="body">
         <div id="dl">
            <form action="dl.php" method="post">
                <input type="text" name="user" id="" placeholder="用户名:" class="logininput">
                <br>
                <input type="password" name="pwd" id="" placeholder="密码:" class="logininput">
                <br>
                <button class="loginbutton" type="button" onclick="zc()">去注册</button>
                <button type="submit" class="loginbutton">登录</button>
            </form>
        </div>

        <div id="zc">
            <form action="zc.php" method="post">
                <input type="text" name="user" id="" placeholder="用户名:" class="logininput">
                <br>
                <input type="password" name="pwd" id="" placeholder="密码:" class="logininput">
                <br>
                <input type="password" name="pwd2" id="" placeholder="确认密码:" class="logininput">
                <br>
                <button type="button" class="loginbutton" onclick="dl()">去登录</button>
                <button type="submit" class="loginbutton">注册</button>
            </form>
                
        </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>|本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供技术支持|</h4>
    </div>
</body>
    <script src="js/index.js"></script>
</html>