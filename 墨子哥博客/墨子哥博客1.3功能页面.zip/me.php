<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
if($users==""){
            echo "<script>alert('你没有权限，请登录')</script>";
            echo"<script>window.location.replace('login.php');</script>";
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <script src="js/index.js"></script>
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                        if($users!=""){
                            echo "欢迎您:&nbsp;".$users;
                        }else{
                            echo "<a href='index.php'>返回</a>";
                        }
                     ?>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
             <?php 
                if($users!=""){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    };
                }else{
                     echo "请登录";
                }
             ?>
        </div>
    </div>
    <!-- body -->
    <div id="body">
        <div id="me_card">
            <?php 
                foreach($rows as $row) {
                    echo "<a href='{$row['img']}'><img src='{$row['img']}' alt='{$row['img']}' class='card_img'></a>";
                    echo "<hr>";
                    echo "用户名:".$row['user'];
                    echo "<hr>";
                    echo "<a href='changhend.php'>修改头像</a>";
                    echo "<hr>";
                    echo "<a href='myfabu.php'>我发布的</a>";
                    echo "<hr>";
                    echo "<a href='unset.php'>退出登录</a>";
                    echo "<hr>";
                }
            ?>
        </div>
    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 60px;">
         <!-- <p>------under line------</p> -->
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>|本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供技术支持|</h4>
    </div>
</body>
</html>