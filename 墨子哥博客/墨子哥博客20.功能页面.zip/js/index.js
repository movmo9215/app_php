// 显示注册栏
function zc(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	dl.style.display="none";
	zc.style.display="block";
}
// 显示登录栏
function dl(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	zc.style.display="none";
	dl.style.display="block";
}
// 关闭发布页面
function x(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="none";
}
// 打开发布页面
function o(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="block";
}
//判断是否要删除——mafabu.php页面
function myfabu_dele(id1){
	var del=confirm("真的要删除吗？");
	if(del==true){
		alert("删除成功");
		window.location.replace("myfabu.php?dele_id="+id1);
	}else{
		// alert("删除失败");
	}
}
//判断是否要删除——end_user.php页面
function end_user_dele(id2){
	var del=confirm("真的要删除"+id2+"的账号吗？");
	if(del==true){
		alert("删除成功");
		window.location.replace("end_user.php?dele_id="+id2);
	}else{
		// alert("删除失败");
	}
}
//判断是否要删除——end_text.php页面
function end_text_dele(id3){
	var del=confirm("真的要删除吗？");
	if(del==true){
		alert("删除成功");
		window.location.replace("end_text.php?dele_id="+id3);
	}else{
		// alert("删除失败");
	}
}
//判断是否退出登录
function user_out(){
	var del=confirm("确认退出登录？");
	if(del==true){
		alert("成功退出");
		window.location.replace("unset.php");
	}
}
//切换夜间模式
function day_night(){
		var btn=document.getElementById('day_night');
	 	var bodys=document.body.classList.toggle('body');
		var btns=btn.classList.toggle('gogobtn');
		localStorage.setItem('dark',bodys);
		localStorage.setItem('btn',btns);
		location.reload();
}
window.onload=function(){
	//查询夜间模式状态
	var bg_dark=localStorage.getItem('dark');
	var btnsell=localStorage.getItem('btn');
	var btn=document.getElementById('day_night');
	if (bg_dark==='true' && btnsell==='true'){
		document.body.classList.add('body');
		btn.classList.add('gogobtn');
		btn.innerText="白";
	}else{
		document.body.classList.remove('body');
		btn.classList.remove('gogobtn');
		btn.innerText="黑";
	}
}


