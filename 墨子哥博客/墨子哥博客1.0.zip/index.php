<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `about`";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                        if($users!=""){
                            echo "欢迎您:&nbsp;".$users;
                        }else{
                            echo "<a href='login.php'>去登录/注册</a>";
                        }
                     ?>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                if($users!=""){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    };
                }else{
                     echo "请登录";
                }
             ?> 
        </div>
    </div>
    <!-- body -->
    <div id="body">
        <!-- card -->
                 <?php
                    if($nr){
                        foreach($nr as $nrs) {
                            $user_s=$nrs['user'];
                            $biaoti_s=$nrs['biaoti'];
                            // $text_s=$nrs['text'];
                            $tp_s=$nrs['tp'];
                            $time_s=$nrs['time'];
                         echo "<div class='box'>
                                    <div class='ml-1'>
                                        <div><h3>{$biaoti_s}</h3></div>
                                       <hr>
                                       <div><img src='{$tp_s}' alt='{$tp_s}' class='card_img'></div>
                                       <hr>
                                       <div><span>发布者:{$user_s}</span>&nbsp;&nbsp;&nbsp;<span>发布时间:{$time_s}</span><a href='' class='flr'>详情-></a></div>
                                    </div>
                                </div>";
                        };
                    }else{
                        echo "本站无数据，需要你们动动小手哟！";
                    }
             ?> 
    </div>

    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 50px;">
        <p>------到底啦!------</p>
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
    <!-- else -->
    <?php 
        if($users!=""){
            echo "
            <div id='sumbit' onclick='o()'>+</div>
                <div id='sumbit_all'>
                    <div id='sumbit_all_x' onclick='x()'>x</div>
                    <div id='sumbit_all_one'>
                        <form action='add.php' method='post' enctype='multipart/form-data'>
                            <hr>
                            <textarea placeholder='标题' class='textarea1' name='biaoti'></textarea>
                            <hr>
                            <textarea placeholder='内容' class='textarea2' name='text'></textarea>
                            <hr>
                                图片上传：<input type='file' name='tp'></input>
                             <button type='submit' class='loginbutton'>上传</button>
                        </form>
                    </div>
                </div>";
        }
     ?>
</body>
    <script src="js/index.js"></script>
</html>