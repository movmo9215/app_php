<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
$biaoti=$_POST['biaoti'];
$text=$_POST['text'];
$time = date("Y/m/d-h:i:s(a)");
if($_FILES["tp"]["error"]>0){
            echo "<script>alert('图片上传错误')</script>";
            echo"<script>window.location.replace('index.php');</script>";
                }
                else{
                    $dir="img/"; 
                    if (!file_exists($dir)) {
                        mkdir($dir);
                    }
                    move_uploaded_file($_FILES["tp"]["tmp_name"], $dir.$_FILES["tp"]["name"]);
                    $tp=$dir.$_FILES["tp"]["name"];
                }
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "INSERT INTO `about`(`id`,`user`, `biaoti`, `text`, `tp` , `time`) VALUES (null,'{$users}','{$biaoti}','{$text}','{$tp}','{$time}')";
        $code=$pdo->exec("$sql");
        if($code>0){
            echo "<script>alert('上传成功,内容待审核')</script>";
            echo"<script>window.location.replace('index.php');</script>";
        }else{
            echo "<script>alert('上传失败,未知错误')</script>";
            echo"<script>window.location.replace('index.php');</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>