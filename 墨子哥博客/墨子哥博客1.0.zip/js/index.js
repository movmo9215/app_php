function zc(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	dl.style.display="none";
	zc.style.display="block";
}
function dl(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	zc.style.display="none";
	dl.style.display="block";
}
function x(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="none";
}
function o(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="block";
}