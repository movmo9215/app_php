<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
$text_id=$_GET['text_id'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `about` WHERE `id`='$text_id'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                        if($users!=""){
                            echo "<a href='index.php'>返回主页</a>";
                        }else{
                            echo "<a href='login.php'>去登录/注册</a>";
                        }
                     ?>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                if($users!=""){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    }
                }else{
                     echo "请登录";
                }
             ?> 
        </div>
    </div>
    <!-- body -->
                 <?php
                    if($nr){
                    foreach($nr as $nrs) {
                        $id_s=$nrs['id'];//id
                        $user_s=$nrs['user'];//用户名
                        $biaoti_s=$nrs['biaoti'];//标题
                        $text_s=$nrs['text'];//描述
                        $about_user_img=$nrs['user_img'];//用户头像
                        $tp_s=$nrs['tp'];//上传的照片
                        $time_s=$nrs['time'];//上传时间
                        if($tp_s=="img/"){
                            echo"<div class='bigbox'>
                                    <div>
                                        <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                        <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                    </div>
                                    <hr>
                                    <div>
                                        <p>描述:{$text_s}</p>
                                    </div>
                                    <hr>
                                    <div>
                                        <span>发布者:{$user_s}</span>&nbsp;&nbsp;&nbsp;<span>发布时间:{$time_s}</span>
                                        <a href='index.php' class='flr'>返回</a>
                                    </div>
                                </div>";
                        }else{
                           echo"<div class='bigbox'>
                                    <div>
                                        <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                        <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                    </div>
                                    <hr>
                                    <div>
                                        <img src='{$tp_s}' alt='{$tp_s}' class='card_img'>
                                        <p>描述:{$text_s}</p>
                                    </div>
                                    <hr>
                                    <div>
                                        <span>发布者:{$user_s}</span>&nbsp;&nbsp;&nbsp;<span>发布时间:{$time_s}</span>
                                        <a href='index.php' class='flr'>返回</a>
                                    </div>
                                </div>";
                        }
                     
                    };
                }else{
                    echo "本站无数据，需要你们动动小手哟！";
                }
             ?> 
    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 50px;">
        <p>------到底啦!------</p>
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
</body>
    <script src="js/index.js"></script>
</html>