<?php 
include('conn.php');
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `about`";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
$dele_id=$_GET['dele_id'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "DELETE FROM `about` WHERE `id`='{$dele_id}'";
        $code=$pdo->exec("$sql");
        if($code>0){
            echo"<script>window.location.replace('end_text.php');</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
// if($users!=""){
//                 // echo "<script>alert('欢迎进入秘密通道')</script>";
// }else{
//                  echo"<script>window.location.replace('login.php');</script>";

// }
unset($pdo);//
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客|end_text</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="end_user.php">用户的信息</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                            echo "<a href='end_text.php'>发布的信息</a>";
                     ?>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                         echo "NEXT";
             ?> 
        </div>
    </div>
    <!-- body -->
                 <?php
                    if($nr){
                        foreach($nr as $nrs) {
                            $id_s=$nrs['id'];//id
                            $user_s=$nrs['user'];//用户名
                            $biaoti_s=$nrs['biaoti'];//标题
                            $text_s=$nrs['text'];//描述
                            $about_user_img=$nrs['user_img'];//用户头像
                            $tp_s=$nrs['tp'];//上传的照片
                            $time_s=$nrs['time'];//上传时间
                            if($tp_s=="img/"){
                                echo"<div class='bigbox'>
                                        <div>
                                            <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                            <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                        </div>
                                        <hr>
                                        <div>
                                            <p>描述:{$text_s}</p>
                                        </div>
                                        <hr>
                                        <div>
                                            <span>发布者:{$user_s}</span>
                                            <hr>
                                            发布时间:{$time_s}</span>
                                            <a href='' onclick='end_text_dele({$id_s})' class='flr'>删除</a>
                                        </div>
                                    </div>";
                            }else{
                               echo"<div class='bigbox'>
                                        <div>
                                            <img src='{$about_user_img}' alt='' id='user_img' style='float: left; margin-left: 5px'>
                                            <h2 style=' margin-left: 20px; line-height: 40px;'>{$biaoti_s}</h2>
                                        </div>
                                        <hr>
                                        <div>
                                            <img src='{$tp_s}' alt='{$tp_s}' class='card_img'>
                                            <p>描述:{$text_s}</p>
                                        </div>
                                        <hr>
                                        <div>
                                            <span>发布者:{$user_s}</span>
                                            <hr>
                                            发布时间:{$time_s}</span>
                                            <a href='' onclick='end_text_dele({$id_s})' class='flr'>删除</a>
                                        </div>
                                    </div>";
                            }
                     
                    }
                }else{
                    echo "<br><br><br><h1>无数据</h1>";
                }
             ?> 
    <div style="text-align: center; clear: both; margin-top: 10px; margin-bottom: 50px;">
        <p>------到底啦!------</p>
    </div>
    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
</body>
    <script src="js/index.js"></script>
</html>