<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
if($_FILES["changhend_img"]["error"]>0){
            echo "<script>alert('无指定图片')</script>";
            echo"<script>window.location.replace('me.php');</script>";
            return false;
                }
                else{
                    $dir="img/"; 
                    if (!file_exists($dir)) {
                        mkdir($dir);
                    }
                    move_uploaded_file($_FILES["changhend_img"]["tmp_name"], $dir.$_FILES["changhend_img"]["name"]);
                    $tp=$dir.$_FILES["changhend_img"]["name"];
                }
                if($_FILES["changhend_img"]==""){
                                echo "<script>alert('头像没有修改')</script>";
                                echo"<script>window.location.replace('me.php');</script>";
                                return false;
                }
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql1 = "UPDATE `user` SET `img`='{$tp}' WHERE `user`='{$users}'";
        $sql2 = "UPDATE `about` SET `user_img`='{$tp}' WHERE `user`='{$users}'";
        $code1=$pdo->exec("$sql1");
        $code2=$pdo->exec("$sql2");
        if($code1>0 && $code2>0){
            echo "<script>alert('上传成功,图片待审核')</script>";
            echo"<script>window.location.replace('me.php');</script>";
        }else{
            echo "<script>alert('上传成功,图片待审核')</script>";
            echo"<script>window.location.replace('me.php');</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>