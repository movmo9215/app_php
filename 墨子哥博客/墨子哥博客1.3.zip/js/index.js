// 显示注册栏
function zc(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	dl.style.display="none";
	zc.style.display="block";
}
// 显示登录栏
function dl(){
	var dl=document.getElementById('dl');//登录
	var zc=document.getElementById('zc');//注册
	zc.style.display="none";
	dl.style.display="block";
}
// 关闭发布页面
function x(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="none";
}
// 打开发布页面
function o(){
	var x=document.getElementById('sumbit_all');//x
	x.style.display="block";
}
// 判断是否上传了图片
function tp(){
	var file1=document.getElementById('index_img').value;
	var file2=document.getElementById('changhend_img').value;
		if (file1=="") {
			alert("图片获取成功");
		}
		if (file2=="") {
			alert("图片获取成功");
		}
		else{
			alert("图片获取失败");
		}
}