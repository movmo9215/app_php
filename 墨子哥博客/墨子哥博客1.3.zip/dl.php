<?php
include('conn.php');
session_start();
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
    $user = $_POST['user'];//4、获取表单元素值，查询用户表
	$pwd = $_POST['pwd'];//4、获取表单元素值，查询用户表
	if ($user=="" && $pwd=="") {
	 		echo "<script>alert('用户名和密码不能为空')</script>";
	 		echo"<script>window.location.replace('login.php');</script>";
	}
	if($user==""){
			echo "<script>alert('用户名不能为空')</script>";
	 		echo"<script>window.location.replace('login.php');</script>";
	}if($pwd==""){
			echo "<script>alert('密码不能为空')</script>";
	 		echo"<script>window.location.replace('login.php');</script>";
	}
		//xss防御
	$arr = ['<','>','/'];//限制字符
	$str=$user.$pwd;//拼接字符
	preg_match_all('#('.implode('|', $arr).')#', $str, $wordsFound);//查询是否存在字符
	$wordsFound = array_unique($wordsFound[0]);//返回的字符结果
	if(count($wordsFound)>=1){
	 		echo "<script>alert('非法输入，请重新尝试')</script>";
	 		echo"<script>window.location.replace('login.php');</script>";
	 		return false;
	}
	else{
		$time = date("Y/m/d-h:i:s(a)");
		$sql = "SELECT * FROM `user` WHERE `user`='{$user}' and `pwd`='{$pwd}'";
		$code=$pdo->query("$sql");
    	if($code && $code->rowCount()){
	 		$_SESSION['user']=$user;
	 		echo "<script>alert('登录成功,已为你跳转页面')</script>";
	 		echo"<script>window.location.replace('index.php');</script>";
	 	}else{
	 		echo "<script>alert('登录失败,用户名或密码错误')</script>";
	 		echo"<script>window.location.replace('login.php');</script>";
	 	}
	}
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>