<?php
header('Content-type:text/html;charset=utf-8');
include ('conn.php'); //2、包含数据源字符串
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
    $name = $_POST['name'];//4、获取表单元素值，查询用户表    
    $sql = "SELECT * FROM `about`";
    $result=$pdo->query($sql);
    if($result && $result->rowCount()){
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $stu =$result->fetchAll();
    }
}catch (PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>miss-留言墙 | 后台</title>
</head>
<body>
	<!-- 头部 -->
	<div id="hend">
		<!-- logo -->
		<div id="logo"><a href="end.php" onclick="lod()">inss-留言墙 | 后台</a></div>
		<!-- 用户个人信息页面 -->
		<div id="me"><a href="end.php" onclick="lod()">刷新</a></div>
	</div>
	<!-- 主体内容 -->
	<div id="body">
				<div id="qew">
					<table>
						<tr>
							<th>ID</th>
							<th>用户</th>
							<th>发布的内容</th>
							<th>操作</th>
						</tr>
						
						
							<?php
								foreach ( $stu as $row) {
									echo "
										<tr>
											<td>{$row['ID']}</td>
											<td>{$row['name']}</td>
											<td>{$row['text']}</td>
											<td><a href='ends.php?id={$row['ID']}'>删除</a></td>
										</tr>
										";
									}
							?>
						
					</table>
				</div>
		<div style="margin-bottom: 40vh;"></div>
	</div>
	<!-- 底部内容 -->
	<div id="end">|墨墨科技-提供技术支持|</div>
</body>
<div id="loading">
	<div id="l">加载中···</div>
</div>
</html>