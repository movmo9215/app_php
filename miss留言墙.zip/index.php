<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>miss-留言墙 | 给别人留言</title>
</head>
<body>
	<!-- 头部 -->
	<div id="hend">
		<!-- logo -->
		<div id="logo"><a href="index.php" onclick="lod()">miss-留言墙</a></div>
		<!-- 用户个人信息页面 -->
		<div id="me" onclick="opens()">相关说明</div>
	</div>
	<!-- 主体内容 -->
	<div id="body">
		<form action="liuy.php" method="post" id="froms" onsubmit="return ast();">
		<div style="width: 100%;">
			<div><input type="text" style="width: 80%; float: left;"  placeholder="输入留言密语/名字/暗号/等" name="name" id="name"></div>
			<span id="info"></span>
			<div><button type="submit" style="width: 20%; float: left;">发送</button></div>
		</div>
		
		<div id="os">
			<textarea  placeholder="对他(她)说的话" name="text" id="text"></textarea>
		</div>
		<a href="me_ss.php" onclick="lod()">查看留言</a
		</form>
	</div>
		
	<!-- 底部内容 -->
	<div id="end">
		墨墨科技版权所有&copy;
		<hr>
		本站由
		<a	href='https://hsk.oray.com/'>贝锐花生壳</a>
		提供
		<a href="https://service.oray.com/question/5571.html">内网穿透</a>
		服务
	</div>
</body>
<div id="czsm">
	<div id="x" onclick="dels()">x</div>
	<div style="margin-left: 50px;margin-right: 50px;position: relative;top: 100px;color: green;">
		<h3>Q:留言密语是什么？</h3>
		<p>M:留言密语是一条"钥匙",你发送的内容,可以通过这个"钥匙"去查看</p>
	</div>
	
	<iframe src="acttion.php" frameborder="0">
	</iframe>
</div>
<div id="loading">
	<div id="l">加载中···</div>
</div>
</html>