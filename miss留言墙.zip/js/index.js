function lod(){
	var loading=document.getElementById('loading');
	loading.style.display="block";
}
function ast(){
	var	input1=document.getElementById('name').value;
	var	info=document.getElementById('info');
	if(input1==""){
		info.innerText="密语不能为空哦~";
		return false;
	}else{
		lod();
		return true;
	}
}
function dels(){
	var czsm=document.getElementById('czsm');
	czsm.style.display="none";
}
function opens(){
	var czsm=document.getElementById('czsm');
	czsm.style.display="block";
}

