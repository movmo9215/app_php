<?php
session_start();//1、开启会话
header('Content-type:text/html;charset=utf-8');
include ('conn.php'); //2、包含数据源字符串			
try{
    $pdo=new PDO($dsn,$user,$pwd);//3、生成PDO对象使用数据源字符串连接数据库
    $name = $_POST['name'];//4、获取表单元素值，查询用户表
    $text = $_POST['text'];
	$time = date("Y/m/d-h:i:s(a)");
    $sqls = "INSERT INTO `about`(`ID`,`name`,`text`,time) VALUES (NULL,'{$name}','{$text}','{$time}')"; 
    $results=$pdo->exec($sqls);
        if($results>0){
            echo "<script>alert('发送成功');</script>";
            header("refresh:0;url='index.php");
        }
        else{
            echo "<script>alert('未知错误！');</script>";
            header("refresh:0;url='index.php'");
        }
    }
catch(PDOException $e){//5、异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//6、关闭连接
?>