<?php
    $dbms='mysql';//数据库类型
    $host='localhost';//主机名
    $port='3306';//数据库对应主机端口，默认情况可省略
    $dbname='wechan';//数据库名称
    $charset='utf8';//数据库字符集
 $user='root'; //数据库管理mysql用户名与密码
 $pwd='root'; //数据库管理mysql密码
    $dsn="$dbms:host=$host;port=$port;dbname=$dbname;charset=$charset";//数据源字符串
?>