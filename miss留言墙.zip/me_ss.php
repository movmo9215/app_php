<?php
header('Content-type:text/html;charset=utf-8');
include ('conn.php'); //2、包含数据源字符串
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
    $name = $_POST['name'];//4、获取表单元素值，查询用户表
    $sql = "SELECT * FROM `about` WHERE `name`='{$name}'";
    $result=$pdo->query($sql);
    if($result && $result->rowCount()){
        $result->setFetchMode(PDO::FETCH_ASSOC);
        $stu =$result->fetchALL();
    }
}catch (PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>miss-留言墙 | 查看留言</title>
</head>
<body>
	<!-- 头部 -->
	<div id="hend">
		<!-- logo -->
		<div id="logo"><a href="index.php" onclick="lod()"><</a></div>
		<!-- 用户个人信息页面 -->
		<div id="me">查看留言</div>
	</div>
	<!-- 主体内容 -->
	<div id="body">
		<form action="me_ss.php" method="post" id="fromss" onsubmit="return ast();">
		<div>
			<div><input type="text" style="width: 80%; float: left;" placeholder="输入留言密语/名字/暗号/等" id="name" name="name" value="<?php echo $name; ?>"></div>
			<div><button type="submit" style="width: 20%; float: left;" id="cs">查询</button></div>
		</div>
				<div id="qew">
					<?php
						if($stu==$e){
							echo "<h3 style='color: white;'>密语错误或不存在~</h3>";
						}else{
							foreach($stu as $row){
							echo "<textarea id='o' disabled >
{$row['time']}
----------------------
{$row['text']}
									</textarea>";
							}
						}
					?>
				</div>
		</form>
		<div style="margin-bottom: 10vh;"></div>
	</div>
	<!-- 底部内容 -->
	<div id="end">|墨墨科技-提供技术支持|</div>
</body>
<div id="loading">
	<div id="l">加载中···</div>
</div>
</html>