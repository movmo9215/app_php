<?php
session_start();
include ('conn.php');
if($_SESSION['username']==""){
    header('Location: xsgl.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title></title>
</head>
<body>
<h1 align='center'>添加学生管理</h1>
<form action="xsgl_gx.php?action=add" method="post"  enctype="multipart/form-data">
        <table width="100%">
            <tr>
                <td>学号</td>
                <td ><input type="text" name="xh" value=""></td>
            </tr>
            <tr>
                <td>姓名</td>
                <td><input type="text" name="xm" value=""></td>
            </tr>
            <tr>
                <td>性别</td>
                <td>
                    <input type="radio" name="xb" value="男">男
                    <input type="radio" name="xb" value="女">女
                </td>
            </tr>
            <tr>
                <td>出生日期</td>
                <td><input type="date" name="csrq" value=""></td>
            </tr>
            <tr>
                <td>入学日期</td>
                <td><input type="date" name="rxrq" value=""></td>
            </tr>
            <tr>
                <td>班级</td>
                <td><input type="text" name="bjmc" value=""></td>
            </tr>
            <tr>
                <td>兴趣爱好</td>
                <td colspan="2">
                    <?php 
                        $ah=array('运动','唱歌','电脑','跳舞','读书');
                        for($i=0;$i<count($ah);$i++){
                            echo "<input type='checkbox' name='xqah[]' value='$ah[$i]' >$ah[$i]";
                        }
                    ?> 
                </td>
            </tr>
            <tr>
                <td>照片</td>
                <td><input type="text" disabled="true" name="zpo" value=""></td>
                <td><input type="file" name="zp"></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align:center;">
                    <a href="xsgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="添加">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table>        
    </form>

</body>
</html>
