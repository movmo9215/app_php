<?php
session_start();//1、开启会话
header('Content-type:text/html;charset=utf-8');
include ('conn.php'); //2、包含数据源字符串			
try{
    $pdo=new PDO($dsn,$user,$pwd);//3、生成PDO对象使用数据源字符串连接数据库
    $username = $_POST['user'];//4、获取表单元素值，查询用户表
            $password = md5($_POST['pwd']);
    $sql = "SELECT * FROM `yhb` WHERE `username`='{$username}' and `password`='{$password}'";		
    $result=$pdo->query("$sql");
    if($result && $result->rowCount()){//(1)如果结果记录集不为空，则设置登录的会话变量，登录成功，返回首页
        echo "<script>alert('登录成功！');</script>";
        $_SESSION['username']=$username;
        header("refresh:0;url='index.php'");				
    }else{//（2）结果对象为空，则登录失败，返回登录页
        echo "<script>alert('参数错误，登录失败！');</script>";
        header("refresh:0;url='login.php'");
    }
}catch (PDOException $e){//5、异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//6、关闭连接
?>