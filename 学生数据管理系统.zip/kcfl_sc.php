<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $scid=$_GET['scid'];
            $scname=$_GET['scname'];
            $sql = "DELETE FROM `kcflb` WHERE `课程分类号`='{$scid}'";
            $result=$pdo->exec($sql);
            if ($result>0) {
                echo "<script>alert('删除成功,删除的分类号为:{$scid}'),location.href='kcfl.php'</script>";
            }else{
                echo "<script>alert('删除失败'),location.href='kcfl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>