<?php   
    session_start();
    if($_SESSION['username']==""){
        header('location:xsgl.php');
        die();
    } 
    include ('conn.php');
    try{
        $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        switch ($_GET['action']){
            case 'add'://add
                $xh = $_POST['xh'];
                $xm = $_POST['xm'];
                $xb = $_POST['xb'];
                $csrq= $_POST['csrq'];
                $rxrq = $_POST['rxrq'];
                $bjmc = $_POST['bjmc'];
                $xqah = $_POST['xqah']; 
                $ahstr=implode("|",$xqah);
                $zpo=$_POST['zpo']; 
                if($_FILES["zp"]["error"]>0){
                    $zp=$zpo;
                }
                else{
                    // $filename=$_FILES["zp"]["name"];
                    // $tmpdir=$_FILES["zp"]["tmp_name"];
                    $dir="zp/"; 
                    if (!file_exists($dir)) {
                        mkdir($dir);
                    }
                    move_uploaded_file($_FILES["zp"]["tmp_name"], $dir.$_FILES["zp"]["name"]);
                    $zp=$dir.$_FILES["zp"]["name"];
                }   
                $sql="INSERT INTO `xsb`(`学号`, `姓名`, `性别`, `出生日期`, `入学日期`, `班级名称`, `兴趣爱好`, `照片`) VALUES ('$xh','$xm','$xb',date('$csrq'),date('$rxrq'),'$bjmc','$ahstr','$zp')";   
                $rw = $pdo->exec($sql);
                if ($rw > 0){
                    echo "<script>alert('添加成功');</script>";
                }else{
                    echo "<script>alert('添加失败');</script>";
                }
                header("refresh:1;url='xsgl.php'");
                break;
            case 'del'://get
                $id = $_GET['id'];
                $sql = "delete from `xsb` where `学号`='$id'";
                $rw = $pdo->exec($sql);
                if ($rw > 0){
                    echo "<script>alert('删除成功！');</script>";
                }else{
                    echo "<script>alert('成绩表中有数据，删除失败！');</script>";
                }
                header("refresh:1;url='xsgl.php'");
                break;
            case 'edit'://post
                $xh = $_POST['xh'];
                $xm = $_POST['xm'];
                $xb = $_POST['xb'];
                $csrq= $_POST['csrq'];
                $rxrq = $_POST['rxrq'];
                $bjmc = $_POST['bjmc'];
                $xqah = $_POST['xqah']; 
                $ahstr=implode("|",$xqah);
                $zpo=$_POST['zpo'];               
                //上传照片
                if($_FILES["zp"]["error"]>0){
                    $zp=$zpo;
                }
                else{
                    // $filename=$_FILES["zp"]["name"];
                    // $tmpdir=$_FILES["zp"]["tmp_name"];
                    $dir="zp/"; 
                    if (!file_exists($dir)) {
                        mkdir($dir);
                    }
                    move_uploaded_file($_FILES["zp"]["tmp_name"], $dir.$_FILES["zp"]["name"]);
                    $zp=$dir.$_FILES["zp"]["name"];
                }         
                $sql = "update `xsb` set `姓名`='$xm', `性别`='$xb',`出生日期`=date('$csrq'),`入学日期`=date('$rxrq'),`班级名称`='$bjmc',`兴趣爱好`='$ahstr',`照片`='$zp' where `学号`='$xh'";
                
                $rw = $pdo->exec($sql);
                if ($rw > 0){
                    echo "<script>alert('修改成功');</script>";
                }else{
                    echo "<script>alert('数据无修改');</script>";
                }
                header("refresh:1;url='xsgl.php'");
                break;
            default:
                header("refresh:1;url='xsgl.php'");
                break;
        }
    }catch (PDOException $e){//异常处理
        echo $e->getMessage().'<br>';
    }
    unset($pdo);//关闭连接
?>
<link rel="stylesheet" href="css/index.css">
