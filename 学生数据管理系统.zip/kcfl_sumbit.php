<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $xgid=$_POST['xgid'];
            $xgname=$_POST['xgname'];
            // die();
            $sql = "UPDATE `kcflb` SET `课程分类名称`='{$xgname}' WHERE `课程分类号`='{$xgid}'";
            $result=$pdo->exec($sql);
            // echo $result;
            // die();
            if ($result>0) {
                echo "<script>alert('修改成功,修改的分类号为:{$xgid},修改的课程名称为:{$xgname}'),location.href='kcfl.php'</script>";
            }else{
                echo "<script>alert('修改失败,因为({$xgname})已存在数据库中'),location.href='kcfl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>