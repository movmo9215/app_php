<form action="kcfl_tj_sumbit.php" method="post">
	<table width="100%">
		<tr>
			<td><span style="color: white;">添加课程名称</span></td>
			<td><input type="text" value="" name="tjkcmc"/></td>
		</tr>

		<tr>
			<td colspan="2" style="text-align: center;"><a href="kcfl.php">返回</a>&nbsp;&nbsp;<input type="submit" value="添加"/></td>
		</tr>
	</table>
</form>
<link rel="stylesheet" href="css/index.css">