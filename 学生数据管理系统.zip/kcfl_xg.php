<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $id=$_GET['id']; 
            $sql = "SELECT * FROM `kcflb` WHERE `课程分类号`={$id}";
            $result=$pdo->query($sql);
            if($result && $result->rowCount()){
                $result->setFetchMode(PDO::FETCH_ASSOC);
                $stu =$result->fetch();
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
	<link rel="stylesheet" href="css/index.css">
<form action="kcfl_sumbit.php?action=edit" method="post">
        <table width="100%" border="1">
            <tr>
                <th>课程分类号</th>
                <th>课程分类名称</th>
            </tr>
            <tr>
                <td><?php echo $stu['课程分类号'];?><input type="" name="xgid" style="display: none" value="<?php echo $stu['课程分类号'];?>"></td>
                <td><input type="" name="xgname" value="<?php echo $stu['课程分类名称'];?>"></td>
            </tr>
            <tr align="center">
                <td colspan="3">
                    <a href="kcfl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="修改"  onclick="loading()">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table> 
    </form>