
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>Document</title>
</head>
<body>
    <?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $cjbh=$_POST['cjbh'];
            $cjcj=$_POST['cjcj'];
            $sql = "UPDATE `cjb` SET 成绩`='{$cjcj}' WHERE `编号`='{$cjbh}'";
            $result=$pdo->exec($sql);
            echo "<h1>{$result}</h1>";
            die();
            if ($result>0) {
                echo "<script>alert('修改成功'),location.href='cjgl.php'</script>";
            }else{
                echo "<script>alert('修改失败),location.href='cjgl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
</body>
</html>