<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $cjid=$_GET['cjid'];
            $sql = "DELETE FROM `cjb` WHERE `编号`='{$cjid}'";
			// echo $sql;
			// die();
            $result=$pdo->exec($sql);
			// echo $result;
			// die();
            if ($result>0) {
                echo "<script>alert('删除成功'),location.href='cjgl.php'</script>";
            }else{
                echo "<script>alert('删除失败'),location.href='cjgl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>