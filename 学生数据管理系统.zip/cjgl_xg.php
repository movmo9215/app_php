<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $id=$_GET['id']; 
            $sql = "SELECT * FROM `cjb` WHERE `编号`={$id}";
            $result=$pdo->query($sql);
            if($result && $result->rowCount()){
                $result->setFetchMode(PDO::FETCH_ASSOC);
                $stu =$result->fetch();
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
	<link rel="stylesheet" href="css/index.css">
<form action="cjgl_sumbit.php" method="post">
        <table width="100%" border="1">
            <tr>
                <th>编号</th>
                <th>学号</th>
                <th>学年</th>
				<th>学期</th>
				<th>课程编号</th>
				<th>成绩</th>
            </tr>
            <tr>
                <td><?php echo $stu['编号'];?><input type="" width="100%" style="display: none;" name="cjbh" value="<?php echo $stu['编号'];?>"></td>
                <td><input type="" style="width:100%;" disabled name="cjxh" value="<?php echo $stu['学号'];?>"></td>
                <td><input type="" style="width:100%;" disabled name="cjxn" value="<?php echo $stu['学年'];?>"></td>
                <td><input type="" style="width:100%;" disabled name="cjxq" value="<?php echo $stu['学期'];?>"></td>
                <td><input type="" style="width:100%;" disabled name="cjkcbh" value="<?php echo $stu['课程编号'];?>"></td>
                <td><input type="" style="width:100%;" name="cjcj" value="<?php echo $stu['成绩'];?>"></td>
            </tr>
            <tr align="center">
                <td colspan="10">
                    <a href="cjgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="确认修改" onclick="loading()">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table> 
    </form>
