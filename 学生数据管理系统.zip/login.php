<?php
include('conn.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title>学生数据管理系统</title>
</head>
<body>
    <div id="hend">
        <div id="logo"><a href="index.php">学生数据信息管理系统</a></div>
        <div id="dl">
            <?php
                if($_SESSION['username']!=""){
                    $q=$_SESSION['username'];
                    echo "用户:$q&nbsp&nbsp&nbsp&nbsp&nbsp"."<a href='unset.php'>退出登录</a>";	
                }else{
                    echo "<a href='index.php'>返回主页</a>";
                }
            
            ?>
        </div>
    </div>

        <div id="text">
            <form action="logins.php" method="post">
                <input type="text" placeholder="用户名" name="user"><br>
                <input type="password" placeholder="密码" name="pwd"><br>
                <button type="submit" onclick="loading()">登录</button>
            </form>
        </div>

    <style>
    body{
        background-color: while;
    }
    #text{
        position:relative;
        margin-top: 200px;
        text-align: center;
    }
    input{
        padding-left: 10px;
        width: 250px;
        height: 30px;
        font-size: 20px;
        margin-top: 10px;
        border: solid  black;
        /*border-radius: 5px;*/
    }
    input:focus{
         outline: none;
         border: solid  greenyellow;
    }
    button{
        width: 80px;
        height: 30px;
        margin-top: 10px;
        border: 0;
        background-color: greenyellow;
        border-radius: 5px;
    }
    button:active{
        width: 50px;
        height: 30px;
        margin-top: 10px;
        border: 0;
        background-color: greenyellow;
        border-radius: 5px;
    }
    </style>
    <div id="loading">
        <div id="loding_text">Loading...</div>
    </div>
     <div id="end"><div id="ends">|&nbsp;墨墨科技版权所有&copy;&nbsp;|&nbsp;2023-6-9&nbsp;|&nbsp;联系方式:<a href="tel:未知号码">*******9215</a>&nbsp;|</div></div>
</body>
   <script src="js/index.js"></script>
</html>