function op(text1,text2){
    var open=document.getElementById(text1);
    var bg=document.getElementById(text2);
    var opens1=open.style.display="none";
    if(opens1){
        open.style.display="block";
        var opens2=open.style.display="block";
        bg.style.background="black";
    }else{
        opens2;
    }
}

function loading(){
    var loading=document.getElementById('loading').style.display="block";
}