<?php
include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
			$kcmc=$_POST['tjkcmc'];
            $sql = "INSERT INTO `kcflb`(`课程分类名称`) VALUES ('{$kcmc}')";
            $result=$pdo->exec($sql);
            if ($result>0) {
                echo "<script>alert('添加课程分类成功,添加的课程名称为:{$kcmc}'),location.href='kcfl.php'</script>";
            }else{
                echo "<script>alert('添加失败'),location.href='kcfl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
?>