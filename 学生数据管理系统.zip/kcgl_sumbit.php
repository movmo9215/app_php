<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $kcbh=$_POST['kcbh'];
            $kcmc=$_POST['kcmc'];
            $kcflh=$_POST['kcflh'];
			$kcbh1=$_POST['kcbh1'];
            $jxks=$_POST['jxks'];
			// echo $kcbh."<hr>".$kcmc."<hr>".$kcflh."<hr>".$jxks."<hr>";
			// die();
            $sql = "UPDATE `kcb` SET `课程编号`='{$kcbh}',`课程名称`='{$kcmc}',`课程分类号`='{$kcflh}',`教学课时`='{$jxks}' WHERE `课程编号`='{$kcbh1}'";
			// echo $sql;
			// die();
            $result=$pdo->exec($sql);
            if($result>0){
				 echo "<script>alert('修改成功'),location.href='kcgl.php'</script>";
            }else{
				 echo "<script>alert('修改失败'),location.href='kcgl.php'</script>";
			}
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>