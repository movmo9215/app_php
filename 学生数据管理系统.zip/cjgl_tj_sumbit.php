<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/index.css">
</head>
<body>
<?php
        include ('conn.php');
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $xh=$_POST['xh'];
            $xn=$_POST['xn'];
            $xq=$_POST['xq'];
            $kcbh=$_POST['kcbh'];
            $cj=$_POST['cj'];
            $sql="INSERT INTO  `cjb` (`编号`, `学号`, `学年`, `学期`, `课程编号`, `成绩`) VALUES (NULL,'{$xh}','{$xn}学年','{$xq}','{$kcbh}','{$cj}')";
            // echo "<h1>{$sql}<h1>";
            // die();
            $result=$pdo->exec($sql);
            if ($result>0) {
                echo "<script>alert('添加成功'),location.href='cjgl.php'</script>";
            }else{
                echo "<script>alert('添加失败'),location.href='cjgl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
?>
</body>
</html>
