-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2023-05-10 10:54:54
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `xs`
--

-- --------------------------------------------------------

--
-- 表的结构 `cjb`
--

CREATE TABLE `cjb` (
  `编号` int(11) NOT NULL,
  `学号` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `学年` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `学期` tinyint(4) NOT NULL,
  `课程编号` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `成绩` float(4,1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `cjb`
--

INSERT INTO `cjb` (`编号`, `学号`, `学年`, `学期`, `课程编号`, `成绩`) VALUES
(1, '200900101', '09学年', 1, 'KC000001', 70.0),
(2, '200900102', '09学年', 1, 'KC000001', 83.0),
(3, '200900103', '09学年', 1, 'KC000001', 62.0),
(4, '200900201', '09学年', 1, 'KC000001', 53.0),
(5, '200900202', '09学年', 1, 'KC000001', 88.0),
(6, '200900203', '09学年', 1, 'KC000001', 72.0),
(7, '200900301', '09学年', 1, 'KC000001', 90.0),
(8, '200900302', '09学年', 1, 'KC000001', 63.0),
(9, '200900303', '09学年', 1, 'KC000001', 48.0),
(10, '200900101', '09学年', 1, 'KC000002', 91.0),
(11, '200900102', '09学年', 1, 'KC000002', 83.0),
(12, '200900103', '09学年', 1, 'KC000002', 77.5),
(13, '200900201', '09学年', 1, 'KC000002', 78.8),
(14, '200900202', '09学年', 1, 'KC000002', 92.0),
(15, '200900203', '09学年', 1, 'KC000002', 68.0),
(16, '200900301', '09学年', 1, 'KC000002', 75.0),
(17, '200900302', '09学年', 1, 'KC000002', 83.0),
(18, '200900303', '09学年', 1, 'KC000002', 55.0),
(19, '200900101', '09学年', 2, 'KC000003', 62.5),
(20, '200900102', '09学年', 2, 'KC000003', 80.0),
(21, '200900103', '09学年', 2, 'KC000003', 79.0),
(22, '200900101', '09学年', 2, 'KC000004', 83.0),
(23, '200900102', '09学年', 2, 'KC000004', 87.0),
(24, '200900103', '09学年', 2, 'KC000004', 88.0),
(25, '200900201', '09学年', 2, 'KC000005', 91.0),
(26, '200900202', '09学年', 2, 'KC000005', 75.0),
(27, '200900203', '09学年', 2, 'KC000005', 63.0),
(28, '200900201', '09学年', 2, 'KC000006', 57.0),
(29, '200900202', '09学年', 2, 'KC000006', 89.0),
(30, '200900203', '09学年', 2, 'KC000006', 93.0),
(31, '200900301', '09学年', 2, 'KC000007', 73.0),
(32, '200900302', '09学年', 2, 'KC000007', 92.0),
(33, '200900303', '09学年', 2, 'KC000007', 82.0),
(34, '200900301', '09学年', 2, 'KC000008', 69.0),
(35, '200900302', '09学年', 2, 'KC000008', 44.0),
(36, '200900303', '09学年', 2, 'KC000008', 88.0);

-- --------------------------------------------------------

--
-- 表的结构 `kcb`
--

CREATE TABLE `kcb` (
  `课程编号` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `课程名称` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `课程分类号` smallint(6) NOT NULL,
  `教学课时` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `kcb`
--

INSERT INTO `kcb` (`课程编号`, `课程名称`, `课程分类号`, `教学课时`) VALUES
('KC000001', '语文', 1, 120),
('KC000002', '数学', 1, 120),
('KC000003', '网页制作', 2, 80),
('KC000004', '图像处理', 2, 80),
('KC000005', '国际贸易', 3, 100),
('KC000006', '会计实务', 3, 80),
('KC000007', '电路原理', 4, 80),
('KC000008', '机械制图', 4, 120),
('KC000009', '高频电路', 4, 80);

-- --------------------------------------------------------

--
-- 表的结构 `kcflb`
--

CREATE TABLE `kcflb` (
  `课程分类号` smallint(6) NOT NULL,
  `课程分类名称` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `kcflb`
--

INSERT INTO `kcflb` (`课程分类号`, `课程分类名称`) VALUES
(1, '基础课'),
(2, '计算机专业'),
(3, '财会专业'),
(4, '机电专业');

-- --------------------------------------------------------

--
-- 表的结构 `xsb`
--

CREATE TABLE `xsb` (
  `学号` varchar(9) COLLATE utf8_unicode_ci NOT NULL,
  `姓名` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `性别` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `出生日期` date NOT NULL,
  `入学日期` date NOT NULL,
  `班级名称` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `兴趣爱好` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `照片` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `xsb`
--

INSERT INTO `xsb` (`学号`, `姓名`, `性别`, `出生日期`, `入学日期`, `班级名称`, `兴趣爱好`, `照片`) VALUES
('200900101', '王勇', '男', '1993-05-08', '2009-09-01', '09计算机班', '', ''),
('200900102', '谢莹', '女', '1993-08-12', '2009-09-01', '09计算机班', '', ''),
('200900103', '张小泉', '男', '1993-07-22', '2009-09-01', '09计算机班', '', ''),
('200900201', '李红英', '女', '1993-06-17', '2009-09-01', '09财会班', '', ''),
('200900202', '钟玉敏', '女', '1993-11-08', '2009-09-01', '09财会班', '', ''),
('200900203', '陈桂枝', '女', '1993-05-11', '2009-09-01', '09财会班', '', ''),
('200900301', '黄大发', '男', '1993-12-03', '2009-09-01', '09机电班', '', ''),
('200900302', '王健', '男', '1992-12-20', '2009-09-01', '09机电班', '', ''),
('200900303', '周小风', '男', '1993-03-13', '2009-09-01', '09机电班', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `yhb`
--

CREATE TABLE `yhb` (
  `id` tinyint(4) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `yhb`
--

INSERT INTO `yhb` (`id`, `username`, `password`) VALUES
(3, 'admin', '21232f297a57a5a743894a0e4a801fc3');

--
-- 转储表的索引
--

--
-- 表的索引 `cjb`
--
ALTER TABLE `cjb`
  ADD PRIMARY KEY (`编号`),
  ADD KEY `fk_xh` (`学号`),
  ADD KEY `fk_kcbh` (`课程编号`);

--
-- 表的索引 `kcb`
--
ALTER TABLE `kcb`
  ADD PRIMARY KEY (`课程编号`),
  ADD KEY `课程分类号` (`课程分类号`);

--
-- 表的索引 `kcflb`
--
ALTER TABLE `kcflb`
  ADD PRIMARY KEY (`课程分类号`);

--
-- 表的索引 `xsb`
--
ALTER TABLE `xsb`
  ADD PRIMARY KEY (`学号`);

--
-- 表的索引 `yhb`
--
ALTER TABLE `yhb`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `cjb`
--
ALTER TABLE `cjb`
  MODIFY `编号` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- 使用表AUTO_INCREMENT `kcflb`
--
ALTER TABLE `kcflb`
  MODIFY `课程分类号` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `yhb`
--
ALTER TABLE `yhb`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- 限制导出的表
--

--
-- 限制表 `cjb`
--
ALTER TABLE `cjb`
  ADD CONSTRAINT `cjb_ibfk_1` FOREIGN KEY (`课程编号`) REFERENCES `kcb` (`课程编号`),
  ADD CONSTRAINT `cjb_ibfk_2` FOREIGN KEY (`学号`) REFERENCES `xsb` (`学号`);

--
-- 限制表 `kcb`
--
ALTER TABLE `kcb`
  ADD CONSTRAINT `kcb_ibfk_1` FOREIGN KEY (`课程分类号`) REFERENCES `kcflb` (`课程分类号`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
