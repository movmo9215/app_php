<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $id=$_GET['id']; 
            $sql = "select * from `xsb` where `学号`='$id'";
            $result=$pdo->query($sql);
            if($result && $result->rowCount()){
                $result->setFetchMode(PDO::FETCH_ASSOC);
                $stu =$result->fetch();
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
	<h1 align='center'>修改学生管理</h1>
<form action="xsgl_sumbit.php?action=edit" method="post"  enctype="multipart/form-data">
<table width="100%">
	<tr>
		<td>学号</td>
		<td ><input type="text" name="xh" readonly="true" value="<?php echo $stu['学号'];?>"></td>
		<td rowspan="6"><img src="<?php echo $stu['照片'];?>" alt="照片"  style="width: 100%; height: 100%;"></td>
	</tr>
	<tr>
		<td>姓名</td>
		<td><input type="text" name="xm" value="<?php echo $stu['姓名'];?>"></td>
	</tr>
	<tr>
		<td>性别</td>
		<td>
			<input type="radio" name="xb" value="男" <?php echo ($stu['性别'] == "男")? "checked":"";?> >男
			<input type="radio" name="xb" value="女" <?php echo ($stu['性别'] == "女")? "checked":"";?> >女
		</td>
	</tr>
	<tr>
		<td>出生日期</td>
		<td><input type="date" name="csrq" value="<?php echo $stu['出生日期'];?>"></td>
	</tr>
	<tr>
		<td>入学日期</td>
		<td><input type="date" name="rxrq" value="<?php echo $stu['入学日期'];?>"></td>
	</tr>
	<tr>
		<td>班级</td>
		<td><input type="text" name="bjmc" value="<?php echo $stu['班级名称']?>"></td>
	</tr>
	<tr>
		<td>兴趣爱好</td>
		<td colspan="10">
		<?php 
			$ahstr=explode("|",$stu['兴趣爱好']);
			$ah=array('运动','唱歌','电脑','跳舞','读书');
			for($i=0;$i<count($ah);$i++){
				if(in_array($ah[$i],$ahstr)){
					echo "<input type='checkbox' name='xqah[]' value='$ah[$i]' checked>$ah[$i]";
				}
				else{
					echo "<input type='checkbox' name='xqah[]' value='$ah[$i]' >$ah[$i]";
				}       
			}
		?> 
		</td>
	</tr>
	<tr>
		<td>照片</td>
		<td><input type="text" name="zpo" value="<?php echo $stu['照片']?>"></td>
		<td><input type="file" name="zp"></td>
	</tr>
	<tr align="center">
		<td colspan="3" style="text-align:center;">
			<a href="xsgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="submit" value="修改">&nbsp;&nbsp;&nbsp;&nbsp;
			<input type="reset" value="重置">
		</td>
	</tr>
</table>
</form>
<link rel="stylesheet" href="css/index.css">
