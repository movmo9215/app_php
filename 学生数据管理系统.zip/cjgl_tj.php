<?php
        include ('conn.php');
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `kcb`";       
            $results=$pdo->query($sql);
            if($results && $results->rowCount()){
                $results->setFetchMode(PDO::FETCH_ASSOC);
                $stu =$results->fetchALL();
            }
        }catch (PDOException $e){//异常处理
                echo $e->getMessage().'<br>';
        }

        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `xsb`";       
            $result=$pdo->query($sql);
            if($result && $result->rowCount()){
                $result->setFetchMode(PDO::FETCH_ASSOC);
                $stus =$result->fetchALL();
            }
        }catch (PDOException $e){//异常处理
                echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
<h1 align='center'>添加学生成绩</h1>
<link rel="stylesheet" href="css/index.css">
<form action="cjgl_tj_sumbit.php" method="post">
        <table width="100%" border="1">
            <tr>
                <th>学号</th>
                <th>学年</th>
                <th>学期</th>
                <th>课程编号</th>
                <th>成绩</th>
            </tr>
            <tr>
                <td><select  style='width:100%;' name="xh">
                        <?php
                            foreach ($stus as $row){
                                echo "<option>{$row['学号']}</option>";
                            }
                        ?>
                    </select>
                </td>
                <td><input type="text" maxlength="2" name="xn" style='width:100%;'  onchange="if(/\D/.test(this.value)){alert('[学年]-只能输入数字');this.value='';}"></td>
                <td><input type="text" maxlength="9" name="xq" style='width:100%;'  onchange="if(/\D/.test(this.value)){alert('[学期]-只能输入数字');this.value='';}"></td>
				<td>
                    <select  style='width:100%;' name="kcbh">
                        <?php
                            foreach ($stu as $row){
                                echo "<option>{$row['课程编号']}</option>";
                            }
                        ?>
                    </select>            
                </td>
				<td><input type="text" name="cj" style='width:100%;'></td>
            </tr>
            <tr align="center">
                <td colspan="10">
                    <a href="cjgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="添加">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table> 
    </form>