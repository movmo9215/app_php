<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $scxs=$_GET['scxs'];
			// echo $scxs;
			// die();
            $sql = "DELETE FROM `xsb` WHERE  `编号`='{$scxs}'";
            $result=$pdo->exec($sql);
            if ($result>0){
                echo "<script>alert('删除成功'),location.href='xsgl.php'</script>";
            }else{
                echo "<script>alert('删除失败,成绩表有数据,请先删除学生成绩'),location.href='xsgl.php'</script>";
            }
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>