<?php
include('conn.php');
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="js/index.js"></script>
	 <link rel="stylesheet" href="css/index.css">
    <title>学生数据管理系统</title>
</head>
<body>
    <div id="hend">
        <div id="logo"><a href="index.php">学生数据信息管理系统</a></div>
        <div id="dl">
            <?php
                if($_SESSION['username']!=""){
                    $q=$_SESSION['username'];
                    echo "管理员:[$q]&nbsp&nbsp&nbsp&nbsp&nbsp";	
                }else{
                    echo "<a href='login.php'>登录</a>";
                }
            
            ?>
        </div>

        <div id="cdls">
            |<a href="kcfl.php" target="o">课程分类管理</a>|
            |<a href="kcgl.php" target="o">课程管理</a>|
            |<a href="xsgl.php" target="o">学生管理</a>|
            |<a href="cjgl.php" target="o">成绩管理</a>|
            <?php
                if($_SESSION['username']!=""){
                    echo "|<a href='unset.php'>退出登录</a>|";    
                }else{
                    echo "|<a href='login.php'>登录</a>|";
                }
            ?>
        </div>
    </div>

    <div id="body">
        <div id="navLeft">
            <hr>
            <div id="1" class="big i"><a href="kcfl.php" target="o">课程分类管理</a></div>
            <hr>
            <div id="2" class="big i"><a href="kcgl.php" target="o">课程管理</a></div>
            <hr>
            <div id="3" class="big i"><a href="xsgl.php" target="o">学生管理</a></div>
            <hr>
            <div id="4" class="big i"><a href="cjgl.php" target="o">成绩管理</a></div>
            <hr>
			<div id="5 dl2" class="big i">
				<?php
				    if($_SESSION['username']!=""){
				        echo "<a href='unset.php'>退出登录</a><hr>";
                    }
				?>
			</div>
        </div>
        <div id="navRight">
            <iframe src="czwd.html" frameborder="0" name="o"></iframe>
        </div>
    </div>
    <div id="loading">
        <div id="loding_text">Loading...</div>
    </div>
    <div id="end"><div id="ends">|&nbsp;墨墨科技版权所有&copy;&nbsp;|&nbsp;2023-6-9&nbsp;|&nbsp;联系方式:<a href="tel:未知号码">*******9215</a>&nbsp;|</div></div>
</body>
</html>