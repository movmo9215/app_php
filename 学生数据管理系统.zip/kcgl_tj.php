<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
			$sql_flb = "SELECT * FROM `kcflb` WHERE `课程分类号`";		
			$results=$pdo->query($sql_flb);
			if($results && $results->rowCount()){
			    $results->setFetchMode(PDO::FETCH_ASSOC);
			    $stus =$results->fetchALL();
			}
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
<h1 align='center'>添加课程管理</h1>
<link rel="stylesheet" href="css/index.css">
<form action="kcgl_tj_sumbit.php" method="post">
        <table width="100%" border="1">
            <tr>
                <th>课程编号</th>
                <th>课程名称</th>
                <th>课程分类号</th>
                <th>教学课时</th>
            </tr>
            <tr>
                <td><input type="" name="kcbh"    style='width:100%;'></td>
                <td><input type="" name="kcmc" style='width:100%;'></td>
				<td>
					<select  style='width:100%;' name="kcflh" onchange="if(/\D/.test(this.value)){alert('教学课时-只能输入数字');this.value='';}">
						<?php
							foreach ($stus as $row){
								echo "<option>{$row['课程分类号']}</option>";
							}
						?>
					</select>
				</td>
				<td><input type="" name="jxks" style='width:100%;'  onchange="if(/\D/.test(this.value)){alert('教学课时-只能输入数字');this.value='';}"></td>
            </tr>
            <tr align="center">
                <td colspan="4">
                    <a href="kcgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="添加">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table> 
    </form>