<?php
session_start();
include ('conn.php');
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
    $sql = "select * from `cjb` order by `编号`";
    $result=$pdo->query($sql);
    if($result && $result->rowCount()){
        $rows=$result->fetchAll();				
    }
}catch (PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($PDO);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title></title>
</head>
<script>
        function doDel(id) {
            if(confirm('确认删除?')) {				
				window.location='cjgl_sc.php?cjid='+id;
            }
        }
</script>
<body>
<h1 align='center'>成绩管理</h1>
</h3>

<table border='1' width='100%' style='text-align: center;'>
        <tr>
            <th>编号</th>
            <th>学号</th>
            <th>学年</th>
            <th>学期</th>
            <th>课程编号</th>
            <th>成绩</th>
            <?php
            	if($_SESSION['username']!=""){
            		echo "<th>操作</th>";
            	}
            ?>	
        </tr>
<?php  //显示学生数据    		 
			foreach ( $rows as $row) {
				echo "<tr>";
				echo "<td>{$row['编号']}</td>";
				echo "<td>{$row['学号']}</td>";
                echo "<td>{$row['学年']}</td>";
				echo "<td>{$row['学期']}</td>";
				echo "<td>{$row['课程编号']}</td>";
				echo "<td>{$row['成绩']}</td>";
		    	if($_SESSION['username']){
		        	echo "<td>
			                  <a href='cjgl_xg.php?id={$row['编号']}'>修改</a>
			                  <a href='javascript:void(0);' onclick='doDel(&quot;{$row['编号']}&quot;)'>删除</a>
			             </td>";
		    	}				  	
			 	echo "</tr>";
		    }
		?>
</table>
<?php 
    if($_SESSION['username']){
    echo "<a href='cjgl_tj.php'>添加成绩</a>";
    }
?>
</body>
</html>