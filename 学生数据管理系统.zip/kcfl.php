<?php
session_start();
include ('conn.php');
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
    $sql = "select * from `kcflb` order by `课程分类号` ";
    $result=$pdo->query($sql);
    if($result && $result->rowCount()){
        $rows=$result->fetchAll();				
    }
}catch (PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($PDO);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/index.css">
    <title></title>
</head>
<script>
        function doDel(id) {
            if(confirm('确认删除?')) {				
				window.location='kcfl_sc.php?scid='+id;
            }
        }
</script>
<body>

<h1 align='center'>课程分类管理</h1>

<table border='1' width='100%' style='text-align: center;'>
        <tr>
            <th>课程分类号</th>
            <th>课程分类名称</th>
            <?php
            	if($_SESSION['username']!=""){
            		echo "<th>操作</th>";
            	}
            ?>	
        </tr>
        <?php  //显示学生数据    		 
			foreach ( $rows as $row) {
				echo "<tr>";
				echo "<td>{$row['课程分类号']}</td>";
				echo "<td>{$row['课程分类名称']}</td>";
		    	if($_SESSION['username']){
		        	echo "<td>
			          <a href='kcfl_xg.php?id={$row['课程分类号']}'>修改</a>
			          <a href='javascript:void(0);' onclick='doDel(&quot;{$row['课程分类号']}&quot;)'>删除</a>
			        </td>";
		    	}	  	
			 	echo "</tr>";
		    }
		?>
</table>
<?php 
    if($_SESSION['username']){
    echo "<a href='kcfl_tj.php'>添加分类</a>";
    }     
?>
</body>
</html>