<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $kcbh=$_POST['kcbh'];
            $kcmc=$_POST['kcmc'];
            $kcflh=$_POST['kcflh'];
            $jxks=$_POST['jxks'];
			// echo $kcbh."<hr>".$kcmc."<hr>".$kcflh."<hr>".$jxks."<hr>";
			// die();
			$sql= "INSERT INTO `kcb`(`课程编号`, `课程名称`, `课程分类号`, `教学课时`) VALUES ('{$kcbh}','{$kcmc}','{$kcflh}','{$jxks}')";
			// echo $sql;
			// die();
            $result=$pdo->exec($sql);
            if($result>0){
				 echo "<script>alert('添加成功'),location.href='kcgl.php'</script>";
            }else{
				 echo "<script>alert('添加失败'),location.href='kcgl.php'</script>";
			}
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>