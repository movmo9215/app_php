<?php      
        include ('conn.php');        
        try{
            $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $xgkcbh=$_GET['xgkcbh']; 
            $sql = "SELECT * FROM `kcb` WHERE `课程编号`='{$xgkcbh}'";
			$sql_flb = "SELECT * FROM `kcflb` WHERE `课程分类号`";
            $result=$pdo->query($sql);
            if($result && $result->rowCount()){
                $result->setFetchMode(PDO::FETCH_ASSOC);
                $stu =$result->fetch();
            }
			
			$results=$pdo->query($sql_flb);
			if($results && $result->rowCount()){
			    $results->setFetchMode(PDO::FETCH_ASSOC);
			    $stus =$results->fetchALL();
				// echo $stus;
				// die();
			}
        }catch (PDOException $e){//异常处理
            echo $e->getMessage().'<br>';
        }
        unset($pdo);//关闭连接
    ?>
	<link rel="stylesheet" href="css/index.css">
	<h1 align='center'>修改课程管理</h1>
<form action="kcgl_sumbit.php" method="post">
        <table width="100%" border="1">
            <tr>
                <th>课程编号</th>
                <th>课程名称</th>
                <th>课程分类号</th>
                <th>教学课时</th>
            </tr>
            <tr>
                <td><input type="" name="kcbh"   value="<?php echo $stu['课程编号'];?>" style='width:100%;'></td>
                <td><input type="" name="kcmc" value="<?php echo $stu['课程名称'];?>" style='width:100%;'></td>
				<td>	
				<input type="text"  name="kcbh1"  style='width:100%; display: none;' value="<?php echo $stu['课程编号'];?>">
						原来的分类号:<input type="text"  style='width:100%;' value="<?php echo $stu['课程分类号'];?>" disabled>
						<hr>
						所修改的分类号:<select  style='width:100%;' name="kcflh">
							<?php
								foreach ($stus as $row){
									echo "<option>{$row['课程分类号']}</option>";
								}
							?>
						</select>
				</td>
				<td><input type="" name="jxks" value="<?php echo $stu['教学课时'];?>" style='width:100%;'  onchange="if(/\D/.test(this.value)){alert('只能输入数字');this.value='';}"></td>
            </tr>
            <tr align="center">
                <td colspan="4">
                    <a href="kcgl.php">返回</a>&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="submit" value="修改">&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="reset" value="重置">
                </td>
            </tr>
        </table> 
    </form>