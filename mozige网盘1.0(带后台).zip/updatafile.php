<?php
include('install/db.php');//引入连接数据库需要的文件
//验证账号信息
session_start();
$username=$_SESSION['user'];
if($username){
}else{	
	echo "<script>alert('请登录')</script>";
	echo "<script>window.location.replace('login.php')</script>";
}
//判断数据库是否连接
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
//查询用户信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_user` WHERE `username`='{$username}'";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
         	$quer_user=$code->fetchAll();//遍历数据表
    }else{//否则
			echo "<script>alert('获取用户数据失败~')</script>";
    }
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
if($quer_user){
	foreach($quer_user as $usercode){
		$info=$usercode['info'];
		if($info==1){
			echo "<script>alert('您的账号涉嫌违规，已禁止您上传文件')</script>";
			echo "<script>window.location.replace('index.php')</script>";
		}
	}
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<script type="text/javascript" src="js/updatafile.js"></script>
	<title>Mozige网盘|[上传文件]</title>
</head>
<body>
	<!-- hend -->
		<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left' href='myfile.php'>我的文件</a>
					<a class='vh_10 left' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>

	<div id="navter">
		<!-- 上传文件 -->
		<h1 style="text-align:center;" >上传文件</h1>
		<div class="box">
			<form action="sumbit.php" method="post" enctype="multipart/form-data" onsubmit="return filet()">
				<div class="file_box">点我上传文件<input type="file" name="appfile" class="file" id="filet"></div>
				<br>
				是否上传到主页:
				<select name="upinfo" >
					<option value="1" >是</option>
					<option value="0" >否</option>
				</select>
				<br>
				[<span style="color:red; font-size: 20px">是</span>:就<span style="color:red; font-size: 20px">公开</span>到主页显示您的文件;]<br>
				[<span style="color:red; font-size: 20px">否</span>:就<span style="color:red; font-size: 20px">不公开</span>到主页显示您的文件,只能自己查看]
				<?php echo "<input name='user' value='{$username}' style='display:none;'>" ?>
				<br>
				<div id="" style="color:red;">支持上传:<br>
					图片[.img.jeg.jpeg.gif.png]格式;<br>
					视频[.mp4]格式;<br>
					音频[.mp3]格式;<br>
					解压包[.zip.7z]格式;<br>
					文本文件[.txt]格式;<br>
					安装包[.apk]格式;<br>
					其他类型暂时无法上传;最大上传10MB。
				</div>
				<hr>
				文件获取状态:[<span id="wan" style="color:red;"></span>]
				<div><button class="btn right" id="upbtn" onclick="oploading()">提交</button></div>
			</form>
		</div>
	</div>
	<div class="end1">Copyright&copy; <a href="http://stakproject.top" target="_black">Mozige</a>  2023</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn end_btns' >(无权限)</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>
	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
	<div id="loading">
		<!-- 定位 位置的 div -->
		<div id="loadingbox">
			<div>
				<span class="yun" id="l1">L</span>
				<span class="yun" id="o1">o</span>
				<span class="yun" id="a1">a</span>
				<span class="yun" id="d1">d</span>
				<span class="yun" id="i1">i</span>
				<span class="yun" id="n1">n</span>
				<span class="yun" id="g1">g</span>
			</div>
		</div>
	</div>
</body>
</html>