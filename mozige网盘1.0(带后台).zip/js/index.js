//打开新的页面
function openweb(link){
	if (link==='#'){
		alert('暂时没有该功能~');
	}
	window.location.replace(link);
}
//打开新的页面，并且让用户确认是否继续操作
function openwebif(link,text){
	if(confirm(text)==true){
		window.location.replace(link);
		return true;
	}else{
		return false;
	}
}
// 注册表单判断
function zhuche(){
	var zhuche = document.getElementById('zhuche');
	var login = document.getElementById('login');
	login.style.display="none";
	zhuche.style.display="block";
}
// 登录表单判断
function login(){
	var zhuche = document.getElementById('zhuche');
	var login = document.getElementById('login');
	zhuche.style.display="none";
	login.style.display="block";
}
// 登录表单判断是否为空
function logins(){
	var a = document.getElementById('a').value;
	var b = document.getElementById('b').value;
	var c = document.getElementById('c');
	var gg="";
	switch(gg){
		case a:
		c.innerText="请填写完整";
		return false;
		break;

		case b:
		c.innerText="请填写完整";
		return false;
		break;
	}
	return true;
}
// 注册表单判断是否为空
function zhuches(){
	var d = document.getElementById('d').value;
	var e = document.getElementById('e').value;
	var f = document.getElementById('f').value;
	var g = document.getElementById('g');
	var ggg="";
	switch(ggg){
		case d:
		g.innerText="请填写完整";
		return false;
		break;

		case e:
		g.innerText="请填写完整";
		return false;
		break;

		case f:
		g.innerText="请填写完整";
		return false;
		break;
	}
	var e = document.getElementById('e').value;
	var f = document.getElementById('f').value;
	var g = document.getElementById('g');
	if(e!=f){
		g.innerText="二次密码不正确";
		return false;
	}
		return true;
}
// 查看文件跳转函数
function see(seeid) {
	window.location.replace('see.php?seeid='+seeid);
}
//下载文件
function downloadFile(url, filename) {
  var element = document.createElement('a');
  element.setAttribute('href', url);
  element.setAttribute('download', filename);
  element.style.display = 'none';
  document.body.appendChild(element);
  element.click();
  document.body.removeChild(element);
}
// 文件提交后显示的内容，返回给用户是否正在上传文件
function oploading(){
	var loading=document.getElementById('loading');
		if (loading){
				loading.style.display="block";
		}
}
function imgapi(){
		setInterval(function(){
			//操作2.根据查窗口宽度,改变背景图片
			var body_vw=document.body.clientWidth;
			// console.log(body_vw);
			if (body_vw>=480) {
				document.body.style.background="url('https://imgapi.xl0408.top/index.php')";
				console.log("已切换背景API:https://imgapi.xl0408.top/index.php");

			}else{
				document.body.style.background="url('https://api.ghser.com/random/pe.php')";
				console.log("已切换背景API:https://api.ghser.com/random/pe.php");
			}
	},0);
}
// 打开公告
function opengg(){
	var gg = document.getElementById('gogao_nav');
	var x = document.getElementById('x');
	gg.classList.toggle('gogao_navs');
		x.classList.toggle('xs');
}
//网页加载成功后的操作
window.onload=function(){
	// 操作1.检查是否是第一次打开网页，是就调用打开公告函数
	if (!localStorage.getItem('opengogao')){
	 	opengg();
	  console.log('第一次进入本站，公告打开');
  	localStorage.setItem('opengogao', 'true');
	} else {
	  console.log('不是第一次进入本站，公告自动回收');
	}
	// imgapi();
}

