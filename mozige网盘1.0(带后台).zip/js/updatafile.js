//检测是否有文件待上传
function filet(){
	var filet = document.getElementById('filet');
	var filets = document.getElementById('filet').value;
	var wan = document.getElementById('wan');
	var upbtn = document.getElementById('upbtn');
	if(filet.value!=""){
		wan.innerHTML="已获取文件:<span style='color:green;' >"+filets+"</span>:待上传";
		upbtn.style.display="block";
		return true;
	}
	else{
		wan.innerText="未获取文件";
		return false;
	}
}
function imgapi(){
		setInterval(function(){
			//操作2.根据查窗口宽度,改变背景图片
			var body_vw=document.body.clientWidth;
			// console.log(body_vw);
			if (body_vw>=480) {
				document.body.style.background="url('https://imgapi.xl0408.top/index.php')";
				console.log("已切换背景API:https://imgapi.xl0408.top/index.php");

			}else{
				document.body.style.background="url('https://api.ghser.com/random/pe.php')";
				console.log("已切换背景API:https://api.ghser.com/random/pe.php");
			}
	},0);
}
window.onload=function(){
	//操作1.实时调用检测函数
	setInterval(function(){
		filet();
	},0)
	// imgapi();
}