<?php
	//详细配置信息
	$db_type = $_POST['db_type'];//选择数据库类型,默认MySQL
	$db_host = $_POST['db_host']; //服务器地址
	$db_name = $_POST['db_name'];//数据库名称
	$sql_user = $_POST['sql_user'];//数据库用户名
	$sql_pwd = $_POST['sql_pwd'];//数据库密码
	$charset = 'utf8';//数据编码
	$hend = "header('Content-Type:text/html;charset=utf-8')";
	$dsn = "$db_type:host=$db_host;dbname=$db_name;charset=$charset";//数据源1,有数据库名称
	$dsnS = "$db_type:host=$db_host;;charset=$charset";//数据源2,无数据库名称
	$file="db.php";
	$l="<?php";
	$r="?>";
		//写入数组
		$updb = array( 
					$l,
   			PHP_EOL.'$db_type = '.'"'.$db_type.'";',
   			PHP_EOL.'$db_host = '.'"'.$db_host.'";',
   			PHP_EOL.'$db_name = '.'"'.$db_name.'";',
   			PHP_EOL.'$sql_user = '.'"'.$sql_user.'";',
   			PHP_EOL.'$sql_pwd = '.'"'.$sql_pwd.'";',
			PHP_EOL.'$charset = '.'"'.$charset.'";',
			PHP_EOL.$hend.';',
			PHP_EOL.'$dsn = '.'"'.$dsn.'";',
			PHP_EOL.$r,
			 );
	//执行写入数据库信息
	$dbinfo = file_put_contents($file,$updb);
	if($dbinfo){
		echo "<script>alert('数据库配置信息写入成功')</script>";
		include('db.php');
		//判断数据库是否连接
		try {
			$pdo = new PDO($dsn,$sql_user,$sql_pwd);
			echo "数据库连接成功";
		} catch (Exception $e) {
			echo "<script>alert('数据库配置信息错误，请检查数据库名称，用户名，密码是否错误~')</script>";
			echo "<script>window.location.replace('index.php')</script>";
		}
		echo "<hr>";
		echo"管理员目录:";
		echo "<hr>";
		echo"/admin/index.php";
		echo "<hr>";
		echo"管理员默认用户名:admin";
		echo "<hr>";
		echo"管理员默认密码:admin123";
		echo "<hr>";
		echo"管理员默认密钥:admin123";
		echo "<hr>";
		echo"<a href='../admin/index.php'>直接进入管理员页面</a>";
		echo "<hr>";
		echo"<a href='../index.php' >主页</a>";
	}else{
		echo "<script>alert('数据库配置信息写入失败')</script>";
		echo"<script>window.location.replace('index.php');</script>";//返回您的网页,这里按你自己需求设定
	}
	//创建数据库
	// try{
	// 	$pdo = new PDO($dsnS,$sql_user,$sql_pwd);//数据源,无数据库的数据源
	// 	$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
	// 	$sql = "CREATE DATABASE $db_name";
	// 	$token = $pdo->exec($sql);
	// 	if($token>0){
	// 		echo "<script>alert('数据库{$db_name}创建成功')</script>";
	// 		//导入数据
	// 		$sqlinstall = file_get_contents($file);
	// 		//新的数据源
	// 		include('db.php');
	// 		$newpdo = new PDO($dsn,$sql_user,$sql_pwd);//数据源,有数据库的数据源
	// 		if ($newpdo->exec($sqlinstall)) {
	// 		    echo "<script>alert('数据库导入成功')</script>";
	// 		} else {
	// 		    echo "导入数据库失败: " . $newpdo->error;
	// 		}
	//         echo"<script>window.location.replace('../index.php');</script>";//返回您的网页,这里按你自己需求设定
	// 	}
	// 	else{
	// 		echo "<script>alert('数据库{$db_name}创建失败')</script>";
	//         echo"<script>window.location.replace('../index.php');</script>";//返回您的网页,这里按你自己需求设定
			
	// 	}
	// } catch (Exception $e) {
	// 		echo "<script>alert('数据库连接错误,请检查数据库用户名,密码,是否正确!')</script>";
	// 		echo "<script>alert('数据库未创建,待连接成功后创建')</script>";
	//         echo"<script>window.history.back();</script>";//返回上一页
	// }
?>