-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- 主机： localhost
-- 生成日期： 2023-07-29 15:46:30
-- 服务器版本： 5.7.26
-- PHP 版本： 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `aaa`
--

-- --------------------------------------------------------

--
-- 表的结构 `pan_admin`
--

CREATE TABLE `pan_admin` (
  `ID` int(11) NOT NULL,
  `adminuser` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adminpwd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `adminkey` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `pan_admin`
--

INSERT INTO `pan_admin` (`ID`, `adminuser`, `adminpwd`, `adminkey`) VALUES
(5, 'admin', '0192023a7bbd73250516f069df18b500', '0192023a7bbd73250516f069df18b500');

-- --------------------------------------------------------

--
-- 表的结构 `pan_config`
--

CREATE TABLE `pan_config` (
  `ID` int(11) NOT NULL,
  `gogao` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `banbenhao` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `pan_config`
--

INSERT INTO `pan_config` (`ID`, `gogao`, `banbenhao`) VALUES
(2, '嗨喽~ 这里是mozige网盘，文件传输小助手，虽然限制了10MB，但是并不影响你们上传(切勿上传涉黄，涉赌，侵权，钓鱼等违法文件，一经发现，后果自负)，站长努力搬砖中，如上传的文件侵权或其他因素给您造成不便，请联系QQ:2039789716,我们会及时解决，谢谢！', '1.0.0');

-- --------------------------------------------------------

--
-- 表的结构 `pan_file`
--

CREATE TABLE `pan_file` (
  `ID` int(255) NOT NULL,
  `user` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_index_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_size` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `upinfo` varchar(1) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- 表的结构 `pan_user`
--

CREATE TABLE `pan_user` (
  `ID` int(10) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `userpwd` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `info` tinyint(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转储表的索引
--

--
-- 表的索引 `pan_admin`
--
ALTER TABLE `pan_admin`
  ADD PRIMARY KEY (`ID`);

--
-- 表的索引 `pan_config`
--
ALTER TABLE `pan_config`
  ADD PRIMARY KEY (`ID`);

--
-- 表的索引 `pan_file`
--
ALTER TABLE `pan_file`
  ADD PRIMARY KEY (`ID`);

--
-- 表的索引 `pan_user`
--
ALTER TABLE `pan_user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `username` (`username`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `pan_admin`
--
ALTER TABLE `pan_admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `pan_config`
--
ALTER TABLE `pan_config`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `pan_file`
--
ALTER TABLE `pan_file`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;

--
-- 使用表AUTO_INCREMENT `pan_user`
--
ALTER TABLE `pan_user`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
