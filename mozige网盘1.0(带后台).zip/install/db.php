<?php
$db_type = "mysql";
$db_host = "localhost";
$db_name = "aaa";
$sql_user = "root";
$sql_pwd = "root";
$charset = "utf8";
header('Content-Type:text/html;charset=utf-8');
$dsn = "mysql:host=localhost;dbname=aaa;charset=utf8";
?>