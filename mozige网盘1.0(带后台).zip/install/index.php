<?php 
	include('db.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>数据库信息配置程序</title>
</head>
<body>
	<div id='div'>
		<?php 
		//判断数据库是否连接
		try {
			$pdo = new PDO($dsn,$sql_user,$sql_pwd);
			echo "数据库已连接成功,无需继续修改";
		} catch (Exception $e) {
			echo "数据库未连接成功";
		}
		?>
		<h1 align="center">数据库信息配置程序</h1>
		<p style="color:red;">注:该程序修改的是连接数据库的基本信息,不会创建数据库,具体步骤如下:</p>
		<p style="color:red;">(1)先在您的phpMyAdmin管理工具上,创建一个你自己命名的数据库</p>
		<p style="color:red;">(2)把<a href="db.sql" target="view_window" onclick="Content-Disposition: attachment; filename='db.sql';">db.sql(基本数据框架)</a>文件下载导入到您刚刚创建的数据库中，就完成啦！</p>
		<form action="install.php"  method="post" onsubmit="return onkey()">
			数据库类型(默认:mysql)<span style="color:red;">*</span>：<br><input id="a" name="db_type" value="mysql">
			<br>
			服务器地址(默认:localhost)<span style="color:red;">*</span>：<br><input id="b" name="db_host" value="localhost">
			<br>
			数据库名称<span style="color:red;">*</span>：<br><input id="c" name="db_name" value="" placeholder="数据库名称">
			<br>
			数据库用户名<span style="color:red;">*</span>：<br><input id="d" name="sql_user" value="" placeholder="你自己的数据库用户名">
			<br>
			数据库密码<span style="color:red;">*</span>：<br><input id="e" name="sql_pwd" value="" placeholder="你自己的数据库密码">
			<div id="f"></div>
			<button type="sumbit">确定</button>
		</form>
	</div>
	<style type="text/css">
		 #div{
		 	position: relative;
			top: 80px;
			width: 80%;
			height: 500px;
			margin: auto;
			padding: 20px;
			border-radius: 10px;
			box-shadow: 1px 1px 10px darkgray;
		}
		input{
			width: 100%;
			height: 25px;
			font-size: 19px;
		}
		button{
			margin-top: 10px;
			height: 50px;
			font-size: 20px;
			background: black;
			color: white;
			width: 100%;
			border-radius: 10px;
		}
		button:active{
			margin-top: 10px;
			height: 50px;
			font-size: 20px;
			background: white;
			color: black;
			width: 100%;
			border-radius: 10px;
		}
		#f{
			color: red;
			font-size: 20px;
		}
	</style>
	<script>
		function onkey(){
			var a = document.getElementById('a').value;
			var b = document.getElementById('b').value;
			var c = document.getElementById('c').value;
			var d = document.getElementById('d').value;
			var e = document.getElementById('e').value;
			var f = document.getElementById('f');
			var g="";
			switch(g){
				case a:
				f.innerText="请填写完整";
				return false;
				break;

				case b:
				f.innerText="请填写完整";
				return false;
				break;

				case c:
				f.innerText="请填写完整";
				return false;
				break;

				case d:
				f.innerText="请填写完整";
				return false;
				break;

				case e:
				f.innerText="请填写完整";
				return false;
				break;
			}
			return true;
		}
	</script>
</body>
</html>