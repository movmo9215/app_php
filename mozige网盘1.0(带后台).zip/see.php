<?php 
//计算文件大小
function trans_byte($byte)
{
    $KB = 1024;
    $MB = 1024 * $KB;
    $GB = 1024 * $MB;
    $TB = 1024 * $GB;
    if ($byte < $KB) {
        return $byte . "B";
    } elseif ($byte < $MB) {
        return round($byte / $KB, 2) . "KB";
    } elseif ($byte < $GB) {
        return round($byte / $MB, 2) . "MB";
    } elseif ($byte < $TB) {
        return round($byte / $GB, 2) . "GB";
    } else {
        return round($byte / $TB, 2) . "TB";
    }
}
include('install/db.php');//引入连接数据库需要的文件
//验证账号信息
session_start();
$username=$_SESSION['user'];
$seeid=$_GET['seeid'];
$seename=$_GET['seename'];
if($username){
}else{	
	echo "<script>alert('请登录')</script>";
	echo "<script>window.location.replace('login.php')</script>";
}
//判断数据库是否连接
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_file` WHERE `ID`='{$seeid}'";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
            $upname=$code->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('你似乎没有上传任何东西~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>Mozige网盘|[<?php echo $seename ?>]上传的资源</title>
</head>
<body>
	<!-- hend -->
		<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left' href='myfile.php'>我的文件</a>
					<a class='vh_10 left' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>

	<div id="navter">
			<div class="seetablebox">
			<table>
			<tr>
				<td>用户</td>
				<td>文件名</td>
				<td>上传时间</td>
				<td>文件大小</td>
				<td>文件类型</td>
			</tr>
				<?php
					if($upname){
						foreach($upname as $up){
						$un=$up['user'];
						$ftime=$up['file_time'];
						$ftype=$up['file_type'];
						$fsize=trans_byte($up['file_size']);
						$fname=$up['file_name'];
						echo 
						"
						<tr>
						<th>{$un}</th>
						<th>{$fname}</th>
						<th>{$ftime}</th>
						<th>{$fsize}</th>
						<th>{$ftype}</th>
						";
						}
					}else{
						echo
						"
						<th>NULL</th>
						<th>NULL</th>
						<th>NULL</th>
						<th>NULL</th>
						<th>NULL</th>
						<tr>";
					}
				?>
				<span style="color:red;"  class="leftt">⬅左滑查看更多信息</span>
		</table>
		</div>

		<div class="seebox">
		<?php
			if($upname){
					foreach($upname as $up){
					$fname=$up['file_name'];
					$ftype=$up['file_type'];
					$finame=$up['file_index_name'];
					$fsize=trans_byte($up['file_size']);
						switch($ftype){
						//图片.png
						case 'image/png':
						echo "<div class'seebox'><img src='file/{$finame}' class='seebox_img'></div>";
						echo "<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>";
						break;
						//图片.jpg
						case 'image/jpg':
						echo "<div class'seebox'><img src='file/{$finame}' class='seebox_img'></div>";
						echo "<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>";
						break;
						//图片.jpeg
						case 'image/jpeg':
						echo "<div class'seebox'><img src='file/{$finame}' class='seebox_img'></div>";
						echo "<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>";
						break;
						//视频.png
						case 'video/mp4':
						echo "<div class'seebox'><video src='file/{$finame}' class='seebox_video' controls></video></div>";
						echo "<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>";
						break;
						//音频.MP3
						case 'audio/mpeg':
						echo "<div class'seebox'><audio src='file/{$finame}' class='seebox_video' controls></div>";
						echo "<div class='btn center' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>";
						break;
						//解压包1.zip
						case 'application/zip':
						echo "<div class'seebox'>
								<p>该文件为zip文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
								<hr>
							  </div>";
						break;
						//解压包2.zip
						case 'application/x-zip-compressed':
						echo "<div class'seebox'>
								<p>该文件为zip文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
								<hr>
							  </div>";
						break;
						//安装包.apk
						case 'application/vnd.android.package-archive':
						echo "<div class'seebox'>
								<p>该文件为zip文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
								<hr>
							  </div>";
						break;
						//文本文档.txt
						case 'text/plain':
						echo "<div class'seebox'>
								<p>该文件为txt文本文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;file/{$finame}&quot;,&quot;{$fname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
								<hr>
							  </div>";
						break;
						}
					}
			}
		?>
		<div class="btn" onclick="openweb('index.php')">返回主页</div>
		<div class="btn" onclick="openweb('myfile.php')">返回我的文件</div>
		</div>

		<?php if($username && $upname){}else{echo "<div class='guding' onclick='openweb(&quot;updatafile.php&quot;)' >👉你还没有上传文件哟~点这上传!</div>";} ?>
	</div>
	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>
	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
</body>
</html>