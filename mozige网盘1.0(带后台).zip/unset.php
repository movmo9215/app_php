<?php 
  session_start();//开启会话
  session_unset();//释放会话变量
  header('location:index.php');//返回主页
 ?>