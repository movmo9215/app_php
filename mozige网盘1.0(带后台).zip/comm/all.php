<?php
include('../install/db.php');
session_start();
//验证账号信息
$username=$_SESSION['user'];//已登录用户的用户名
//基本信息获取
$str=$_GET['all'];//需要操作的参数名
//删除操作-基本信息获取
$did=$_POST['did'];//需要删除的id
$dun=$_POST['dun'];//需要删除文件的用户验证
$dfin=$_POST['dfin'];//需要删除的文件名
//登录注册操作-基本信息获取
$user=$_POST['user'];//注册或登录的用户名
$pwd=$_POST['pwd'];//注册或登录的密码
//修改密码操作-基本信息获取
$pwd1=md5($_POST['pwd1']);//原来的密码
$pwd2=md5($_POST['pwd2']);//新密码
//后台管理员登录操作-基本信息获取
$admin_user=$_POST['admin_user'];//管理员用户名
$admin_pwd=md5($_POST['admin_pwd']);//管理员密码
$admin_key=md5($_POST['admin_key']);//管理员唯一密钥
//后台管理员删除操作-基本信息获取
$admin_did=$_POST['admin_did'];//id
$admin_dun=$_POST['admin_dun'];//管理员名称
$admin_dfin=$_POST['admin_dfin'];//该删除文件名
//后台管理员修改用户信息操作-基本信息获取
$userid=$_GET['userid'];//id
$up=$_GET['up'];//修改信息
//后台管理员修改配置信息信息操作-基本信息获取
$gogao=$_POST['gogao'];
$banbenhao=$_POST['banbenhao'];
$newbanbenhao=$_POST['newbanbenhao'];
//后台管理员修改后台信息操作-基本信息获取
$adminID=$_POST['adminID'];//管理员ID
$adminuser=$_POST['adminuser'];//管理员用户名
$adminpwd=md5($_POST['adminpwd']);//管理员密码
$adminkey=md5($_POST['adminkey']);//管理员唯一密钥
//xss防御
$arr = ['<','>'];//限制字符
$qq_str=$user.$pwd;//拼接字符
preg_match_all('#('.implode('|', $arr).')#', $qq_str, $wordsFound);//查询是否存在字符
$wordsFound = array_unique($wordsFound[0]);//返回的字符结果
if(count($wordsFound)>=1){
        echo "<script>alert('非法输入，请重新尝试')</script>";
        echo"<script>window.location.replace('../login.php');</script>";
}
//1注册操作
if($str==="zhuche" && $user and $pwd !=""){
    try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql="INSERT INTO `pan_user`(`ID`, `username`, `userpwd`, `info`) VALUES (null,'{$user}',MD5('{$pwd}'),'0')";//可在数据库复制
            $code=$pdo->exec($sql);//预执行语句
            if($code>0){//成功返回1，不成功返回0，所已大于0就执行下面的语句
               session_start();
               $_SESSION['user']=$user;
               echo "<script>alert('注册成功')</script>";
               echo"<script>window.location.replace('../index.php');</script>";//返回提交时的地址
            }else{
                echo "<script>alert('注册失败,该用户名已被占用')</script>";
                echo"<script>window.location.replace('../login.php');</script>";//返回提交时的地址
            }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//2登录操作
if($str==="login" && $user and $pwd !=""){
        try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `pan_user` WHERE `username`='{$user}' and `userpwd`=MD5('{$pwd}')";//可在数据库复制
            // echo $sql;
            // die();
            $code=$pdo->query($sql);//预查询语句
            if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
               session_start();
               $_SESSION['user']=$user;
               echo "<script>alert('登录成功')</script>";
               echo"<script>window.location.replace('../index.php');</script>";//返回提交时的地址
        }else{//否则
                echo "<script>alert('登录失败')</script>";//提示无数据
                echo"<script>window.history.back();</script>";//返回上一页
                return false;
        }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//用户删除操作
if($username!="" && $username===$dun){//用户登录了并且删除的用户名是当前用户时，才有权限删除
     //3.删除操作1(删除服务器文件)
    if($str==="dele"){
        $filePath = '../file/'.$dfin;//定义要删除的文件路径
        $form_dele_sql=file_exists($filePath);//查询文件是否存在
        $dele_sql_true=unlink($filePath);//预执行删除文件函数
        if ($form_dele_sql){//判断文件是否存在
            $dele_sql_true;//存在就执行删除语句
        }
        else{
            echo "<script>alert('文件不存在')</script>";//提示文件不存在
        }
        //3.删除操作2(删除sql数据)
        try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "DELETE FROM `pan_file` WHERE `ID`='{$did}'";//可在数据库复制
            $code=$pdo->exec($sql);//预删除语句
                if($code>0){//执行删除语句
                    echo "<script>alert('删除成功')</script>";//提示删除成功
                    echo"<script>window.location.replace('../myfile.php');</script>";//返回上一页
                }
                else{
                    echo "<script>alert('删除失败')</script>";//提示删除失败
                    echo"<script>window.location.replace('../myfile.php');</script>";//返回上一页
                    return false;
                }
        }catch(PDOException $e){//异常处理
            echo "ERROR:".$e->getMessage();
        }
    }
}
//修改密码操作
if($username!="" && $username===$dun){//用户登录了并且修改的用户名是当前用户时，才有权限修改
    if($str==="upmima"){
        //1.先查询原来的密码是否匹配
        try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `pan_user` WHERE `userpwd`='{$pwd1}'";//可在数据库复制
            $code=$pdo->query($sql);//预查询语句
            if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
                    $upmima = "UPDATE `pan_user` SET `userpwd`='{$pwd2}' WHERE `username`='{$username}'";//预修改参数
                    $go_upmima=$pdo->exec($upmima);//预修改语句
                    if($go_upmima>0){
                        echo "<script>alert('修改成功,已为你退出登录')</script>";//提示修改成功
                        echo"<script>window.location.replace('../unset.php');</script>";//返回上一页
                    }else{
                        echo "<script>alert('未知错误')</script>";//提示修改成功
                        echo"<script>window.location.replace('../upmima.php');</script>";//返回上一页
                    }
                }
                else{
                    echo "<script>alert('修改失败,原密码错误')</script>";//提示修改失败
                    echo"<script>window.location.replace('../upmima.php');</script>";//返回上一页
                    return false;
                }
        }catch(PDOException $e){//异常处理
            echo "ERROR:".$e->getMessage();
        }
    }
}
//管理员登录操作
if($str==="admin"){
    try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_admin` WHERE `adminuser`='{$admin_user}' and `adminpwd`='{$admin_pwd}' and `adminkey`='{$admin_key}'";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时
            $_SESSION['admin_key']=$admin_key;
            echo "<script>alert('登录成功')</script>";
            echo"<script>window.location.replace('../admin/home.php');</script>";
            }
            else{
                echo "<script>alert('鉴权错误')</script>";
                echo"<script>window.location.replace('../admin/index.php');</script>";
                return false;
            }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//管理员删除操作
if($admin_dun!=""){//用户登录了并且删除的用户名是当前用户时，才有权限删除
     //3.删除操作1(删除服务器文件)
    if($str==="admindele"){
        $filePath = '../file/'.$admin_dfin;//定义要删除的文件路径
        $form_dele_sql=file_exists($filePath);//查询文件是否存在
        $dele_sql_true=unlink($filePath);//预执行删除文件函数
        if ($form_dele_sql){//判断文件是否存在
            $dele_sql_true;//存在就执行删除语句
        }
        else{
            echo "<script>alert('TOP:文件不存在')</script>";//提示文件不存在
        }
        //3.删除操作2(删除sql数据)
        try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "DELETE FROM `pan_file` WHERE `ID`='{$admin_did}'";//可在数据库复制
            $code=$pdo->exec($sql);//预删除语句
                if($code>0){//执行删除语句
                    echo "<script>alert('TOP:删除成功')</script>";//提示删除成功
                    echo"<script>window.location.replace('../admin/file.php');</script>";//返回上一页
                }
                else{
                    echo "<script>alert('TOP:删除失败')</script>";//提示删除失败
                    echo"<script>window.location.replace('../admin/file.php');</script>";//返回上一页
                    return false;
                }
        }catch(PDOException $e){//异常处理
            echo "ERROR:".$e->getMessage();
        }
    }
}
//修改用户权限操作
if($str==="userinfo"){
    try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "UPDATE `pan_user` SET `info`={$up} WHERE `ID`={$userid}";//可在数据库复制
        $code=$pdo->exec($sql);//预删除语句
            if($code>0){//执行删除语句
                echo "<script>alert('TOP:修改成功')</script>";//提示修改成功
                echo"<script>window.location.replace('../admin/user.php');</script>";//返回上一页
            }
            else{
                echo "<script>alert('TOP:修改失败')</script>";//提示修改失败
                echo"<script>window.location.replace('../admin/user.php');</script>";//返回上一页
                return false;
            }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//修改配置信息操作
if($str==="config"){
    try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "UPDATE `pan_config` SET `gogao`='{$gogao}', `banbenhao`='{$newbanbenhao}' WHERE `banbenhao`='{$banbenhao}'";//可在数据库复制
        // echo $sql;
        // die();
        $code=$pdo->exec($sql);//预修改语句
            if($code>0){//执行修改语句
                echo "<script>alert('TOP:修改成功')</script>";//提示修改成功
                echo"<script>window.location.replace('../admin/config.php');</script>";//返回上一页
            }
            else{
                echo "<script>alert('TOP:修改失败')</script>";//提示修改失败
                echo"<script>window.location.replace('../admin/config.php');</script>";//返回上一页
                return false;
            }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//修改管理员信息配置信息操作
if($str==="admin_xiugai"){
    try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "UPDATE `pan_admin` SET `adminuser`='{$adminuser}',`adminpwd`='{$adminpwd}',`adminkey`='{$adminkey}' WHERE `ID`={$adminID}";//可在数据库复制
        $code=$pdo->exec($sql);//预修改语句
            if($code>0){//执行修改语句
                echo "<script>alert('TOP:修改成功')</script>";//提示修改成功
                echo"<script>window.location.replace('../admin/unset.php');</script>";//返回上一页
            }
            else{
                echo "<script>alert('TOP:修改失败')</script>";//提示修改失败
                echo"<script>window.location.replace('../admin/admin.php');</script>";//返回上一页
                return false;
            }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
}
//其他一律返回主页
else{
    echo "<script>alert('无权限')</script>";//提示权限
    echo"<script>window.location.replace('../index.php');</script>";//返回登录页
    return false;
}
?>