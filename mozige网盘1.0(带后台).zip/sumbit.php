<?php
	session_start();
	$allow_exts = array('jpg', 'jpeg', 'gif', 'png', 'mp3', 'mp4', 'zip', '7z', 'txt', 'apk');
	$upload_dir = 'file/';
	$max_size = 10240 * 1024;//到这里修改文件大小限制
	if ($_FILES['appfile']['error'] != UPLOAD_ERR_OK) {
		echo "<script>alert('上传失败,没有选择文件')</script>";
		echo "<script>window.location.replace('updatafile.php')</script>";
		return false;
	}
	//构造文件随机名称函数
	$base = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
	$count = strlen($base);
	$random = '';
	for ($i=0; $i <	32; $i++) { 
	$random.=$base[rand(0,$count-1)];
	}
	//收集数据信息
	$username=$_SESSION['user'];//用户名
	$temp_file = $_FILES['appfile']['tmp_name'];//预上传目录
	$file_name = $_FILES['appfile']['name'];//预留件名
	$file_name_type=explode('.',$file_name);//截取文件类型名称
	$file_index_name = $random.".".end($file_name_type);//修改的新文件名
	$file_time = date("Y/m/d-h:i:s(a)");//上传时间
	$file_type = $_FILES['appfile']['type'];//文件类型
	$file_size = $_FILES['appfile']['size'];//文件大小
	$upinfo = $_POST['upinfo'];
	//判断文件是否ERROR
	$file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
	if (!in_array($file_ext, $allow_exts)) {
		echo "<script>alert('文件类型不符合要求')</script></script>";
		echo "<script>window.location.replace('updatafile.php')</script>";
		return false;
	}
	if ($_FILES['appfile']['size'] > $max_size) {
		echo "<script>alert('文件类型超过10M,不给予上传')</script></script>";
		echo "<script>window.location.replace('updatafile.php')</script>";
		return false;
	}
	if (!is_uploaded_file($temp_file)) {
		echo "<script>alert('非法上传,已警告')</script></script>";
		echo "<script>window.location.replace('updatafile.php')</script>";
		return false;
	}
	if (!file_exists($upload_dir)) {
		mkdir($upload_dir);
	}
	if (move_uploaded_file($temp_file, $upload_dir . $file_index_name)) {
		//连接数据库操作
		include('install/db.php');
		try {
			$pdo = new PDO($dsn,$sql_user,$sql_pwd);
			$code = "INSERT INTO `pan_file`(`ID`, `user`, `file_index_name`, `file_name`, `file_time`, `file_type`, `file_size`, `upinfo`) VALUES (NULL,'{$username}','{$file_index_name}','{$file_name}','{$file_time}','{$file_type}','{$file_size}','{$upinfo}')";
			// echo $code;
			// die();
			$sql = $pdo->exec($code);
			if($sql>0){
				echo "<script>alert('上传成功')</script></script>";
				echo "<script>window.location.replace('index.php')</script>";
			}else{
				echo "<script>alert('上传失败')</script></script>";
				echo "<script>window.location.replace('updatafile.php')</script>";
			}
		}catch (Exception $e) {
			
		}
	}
?>