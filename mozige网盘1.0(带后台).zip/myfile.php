<?php 
//计算文件大小
function trans_byte($byte)
{
    $KB = 1024;
    $MB = 1024 * $KB;
    $GB = 1024 * $MB;
    $TB = 1024 * $GB;
    if ($byte < $KB) {
        return $byte . "B";
    } elseif ($byte < $MB) {
        return round($byte / $KB, 2) . "KB";
    } elseif ($byte < $GB) {
        return round($byte / $MB, 2) . "MB";
    } elseif ($byte < $TB) {
        return round($byte / $GB, 2) . "GB";
    } else {
        return round($byte / $TB, 2) . "TB";
    }
}
include('install/db.php');//引入连接数据库需要的文件
//验证账号信息
session_start();
$username=$_SESSION['user'];
if($username){
}else{	
	echo "<script>alert('请登录')</script>";
	echo "<script>window.location.replace('login.php')</script>";
}
//判断数据库是否连接
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_file` WHERE `user`='{$username}'";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
            $upname=$code->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('你似乎没有上传任何东西~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>Mozige网盘|[<?php echo $username ?>]上传的资源</title>
</head>
<body>
	<!-- hend -->
		<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left a_active' href='myfile.php'>我的文件</a>
					<a class='vh_10 left' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>

	<div id="navter">
		<!-- 我的资源 -->
		<div class="tablebox">
		<table>
			<tr>
				<td colspan="10">[<?php echo $username ?>]的文件夹</td>
			</tr>
				<?php
				if($upname){//有数据就遍历数据
					foreach($upname as $up){
					$un=$up['user'];
					$uID=$up['ID'];
					$fname=$up['file_name'];
					$ftime=$up['file_time'];
					$fsize=trans_byte($up['file_size']);
					$finame=$up['file_index_name'];
					$ftype=$up['file_type'];
						switch($username){
						case $username===$username://有用户名验证信息时，就有查看权限
							echo "
							<tr>
								<td>{$fname}
								<span style='color:greenyellow; cursor: pointer;' onclick='openweb(&quot;see.php?seeid={$uID}&seename={$username}&quot;)'>\查看/</span>
								</td>
								</tr>
							<tr>
								";
							echo "<tr>";
								echo "<th>";
									switch($ftype){
									//图片.png
									case 'image/png':
									echo "<div class'seebox'><img src='file/{$finame}' width='300px' hight='300px'></div>";
									break;
									//图片.jpg
									case 'image/jpg':
									echo "<div class'seebox'><img src='file/{$finame}' width='300px' hight='300px'></div>";
									break;
									//图片.jpeg
									case 'image/jpeg':
									echo "<div class'seebox'><img src='file/{$finame}' width='300px' hight='300px'></div>";
									break;
									//视频.png
									case 'video/mp4':
									echo "<div class'seebox'><video src='file/{$finame}' width='300px' hight='300px' controls></video></div>";
									break;
									//音频.MP3
									case 'audio/mpeg':
									echo "<div class'seebox'><audio src='file/{$finame}' class='seebox_video' controls></div>";
									break;
									//文本文档.txt
									case 'text/plain':
									echo "";
									break;
									//解压包1.zip
									case 'application/zip':
									echo "";
									break;
									//解压包2.zip
									case 'application/x-zip-compressed':
									echo "";
									break;
									//安装包.apk
									case 'application/vnd.android.package-archive':
									echo "";
									break;
									}
									echo "<form action='comm/all.php?all=dele' method='post' onsubmit='return openwebif(&quot#&quot,&quot数据会彻底删除，确定要删除吗&quot)'>
											<span><button class='btn right' type='sumbit' >删除</button></span>
											<input name='did' value='{$uID}' style='display:none'>
											<input name='dun' value='{$un}' style='display:none'>
											<input name='dfin' value='{$finame}' style='display:none'>
										</form>";
								echo "</th>";
							echo "</tr>";
							echo "<tr>";
								echo "<th>";
									echo "{=-=-=-=-=-=-=-END-=-=-=-=-=-=-=}";
								echo "</th>";
							echo "</tr>";
						break;
						//没用户名验证信息时，就没查看权限
						case $username==="":
						echo "
						<tr>
							<th>{$un}	</th>
							<th>{$fname}</th>
						</tr>
							";
						break;
						}
					}
				}else{//木有数据就显示为空值
					echo "
						<th>NULL</th>
						<th>NULL</th>
						";
				}
				?>
				<span style="color:red;"  class="leftt">⬅左滑查看更多信息</span>
		</table>
		</div>
		<?php if($username && $upname){}else{echo "<div class='guding' onclick='openweb(&quot;updatafile.php&quot;)' >👉你还没有上传文件哟~点这上传!</div>";} ?>
	</div>
	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn end_btns' >(无权限)</div>
				 <div class='end_btn' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>
	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
</body>
</html>