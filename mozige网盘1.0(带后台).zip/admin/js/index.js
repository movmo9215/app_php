function opensmall(){
	var manu=document.getElementById('admin_smallmanu');
	manu.classList.toggle('admin_smallmanus');
}