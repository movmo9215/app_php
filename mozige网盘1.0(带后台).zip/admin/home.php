<?php
	include('../install/db.php');//引入连接数据库需要的文件
	//验证账号信息
	session_start();
	if($key=$_SESSION['admin_key']!=""){
	}else{
		echo "<script>alert('鉴权错误')</script>";
		echo "<script>window.location.replace('index.php')</script>";
	}





	//判断数据库是否连接
	try {
		$pdo = new PDO($dsn,$sql_user,$sql_pwd);
		// echo "数据库连接成功";
	} catch (Exception $e) {
		echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
		echo "<script>window.location.replace('install/index.html')</script>";
	}





	//查询文件数据信息
	try{
	    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
	        $sql = "SELECT * FROM `pan_file`";//可在数据库复制
	        $code=$pdo->query($sql);//预查询语句
	        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
	            $quer_file=$code->fetchAll();//遍历数据表
	    	}else{
				echo "<script>alert('获取文件数据失败~')</script>";
	    	}
	}catch(PDOException $e){//异常处理
	    echo "ERROR:".$e->getMessage();
	}



	//查询用户信息
	try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `pan_user`";//可在数据库复制
            $code=$pdo->query($sql);//预查询语句
            if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
             	$quer_user=$code->fetchAll();//遍历数据表
        }else{//否则
				echo "<script>alert('获取用户数据失败~')</script>";
        }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/medio.css">
	<script type="text/javascript" src="../js/index.js"></script>
	<script type="text/javascript" src="js/index.js"></script>
	<title>mozige网盘|后台[主页]</title>
</head>
<body>
	<!-- hend -->
	<div id="hend">
		<div id="bigmanu">
					<a class='toubin toubin_active' href='home.php' target="top">主页</a>
					<a class='toubin ' href='file.php'>文件管理</a>
					<a class='toubin ' href='user.php'>用户管理</a>
					<a class='toubin ' href='config.php'>配置信息管理</a>
					<a class='toubin ' href='admin.php'>后台信息管理</a>
					<a class='toubin ' href='unset.php'>安全退出</a>
		</div>

		<div id="admin_smallmanu" class="admin_smallmanu">
					<div class='small_btn'><a href='home.php' target="top">主页</a></div>
					<hr>
					<div class='small_btn'><a href='file.php'>文件管理</a></div>
					<hr>
					<div class='small_btn'><a href='user.php'>用户管理</a></div>
					<hr>
					<div class='small_btn'><a href='config.php'>配置信息管理</a></div>
					<hr>
					<div class='small_btn'><a href='admin.php'>后台信息管理</a></div>
					<hr>
					<div class='small_btn'><a href='unset.php'>安全退出</a></div>
					<hr>
		</div>
		<div id="right_btn" class="right_btn" onclick="opensmall()">OPEN</div>
	</div>

	<div id="adminbox">
		<h1>数据分析:</h1>
		<?php
		try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据
		$sqluserall="SELECT COUNT(`id`) AS userall FROM `pan_user`";
        $codeall=$pdo->query($sqluserall);//预查询语句
        if($row = $codeall->fetch(PDO::FETCH_ASSOC)){
        	$uall=$row['userall'];
        	echo "<hr><h1>用户统计：[{$uall}]</h1>";
        }
	    }catch(PDOException $e){//异常处理
	        echo "ERROR:".$e->getMessage();
	    }
	    try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据
		$fsq="SELECT COUNT(`id`) AS userall FROM `pan_file`";
        $codefile=$pdo->query($fsq);//预查询语句
        if($rowfile = $codefile->fetch(PDO::FETCH_ASSOC)){
        	$fall=$rowfile['userall'];
        	echo "<hr><h1>上传数据统计：[{$fall}]</h1>";
        }
	    }catch(PDOException $e){//异常处理
	        echo "ERROR:".$e->getMessage();
	    }
		?>
		<hr>
		<h1>用户:</h1>
		<table>
			<tr>
				<td>用户名</td>
				<td>用户状态</td>
			</tr>
			<?php
			if($quer_user){
				foreach($quer_user as $quser){
					$quser_=$quser['username'];
					$quinfo_=$quser['info'];
					if ($quinfo_===1) {
						$quinfo_="<span class='user_false'>异常</span>";
					}else{
						$quinfo_="<span class='user_true'>正常</span>";
					}
					echo "
							<tr>
								<th>{$quser_}</th>
								<th>{$quinfo_}</th>
							</tr>

						 ";
				}
			}
			else{
				echo"<tr>
						<th>获取用户数据失败</th>
						<th>获取用户数据失败</th>
					 <tr>";
			}
			?>
		</table>
		<br>
		<hr>
		<h1>文件：</h1>
		<table>
			<tr>
				<td>用户名</td>
				<td>文件名</td>
				<td>预览</td>
			</tr>
			<?php
			if($quer_file){
				foreach($quer_file as $qfile){
					$qusername=$qfile['user'];//用户名
					$qtype=$qfile['file_type'];//文件类型
					$qfiname=$qfile['file_index_name'];//文件名(加密)
					$qfname=$qfile['file_name'];//文件名
					echo "<tr>";
					echo "
							<th>{$qusername}</th>
							<th>{$qfname}</th>
						 ";
					echo "<th style='width:300px;'>";
					switch($qtype){
						//图片.png
						case 'image/png':
						echo "<div class'seebox'><img src='../file/{$qfiname}' class='seebox_img'></div>";
						break;
						//图片.jpg
						case 'image/jpg':
						echo "<div class'seebox'><img src='../file/{$qfiname}' class='seebox_img'></div>";
						break;
						//图片.jpeg
						case 'image/jpeg':
						echo "<div class'seebox'><img src='../file/{$qfiname}' class='seebox_img'></div>";
						break;
						//视频.png
						case 'video/mp4':
						echo "<div class'seebox'><video src='../file/{$qfiname}' class='seebox_video' controls></video></div>";
						break;
						//音频.MP3
						case 'audio/mpeg':
						echo "<div class'seebox'><audio src='../file/{$qfiname}' class='seebox_video' controls></div>";
						break;
						//解压包1.zip
						case 'application/zip':
						echo "<div class'seebox'>
								<p>该文件为zip文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;../file/{$qfiname}&quot;,&quot;{$qfname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
							  </div>";
						break;
						//解压包2.zip
						case 'application/x-zip-compressed':
						echo "<div class'seebox'>
								<p>该文件为zip文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;../file/{$qfiname}&quot;,&quot;{$qfname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
							  </div>";
						break;
						//安装包.apk
						case 'application/vnd.android.package-archive':
						echo "<div class'seebox'>
								<p>该文件为apk文件,可下载安装,谨慎安装哟</p>
								<div class='btn' onclick='downloadFile(&quot;../file/{$qfiname}&quot;,&quot;{$qfname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
							  </div>";
						break;
						//文本文档.txt
						case 'text/plain':
						echo "<div class'seebox'>
								<p>该文件为txt文本文件,不能预览</p>
								<div class='btn' onclick='downloadFile(&quot;../file/{$qfiname}&quot;,&quot;{$qfname}&quot;)' >点击下载文件(将消耗<span style='color:red;' >{$fsize}</span>流量哟，亲~)</div>
							  </div>";
						break;
						}
					echo "</th>";
					echo "</tr>";
				}
			}
			else{
				echo"<tr>
						<th>获取用户数据失败</th>
						<th>获取用户数据失败</th>
					 <tr>";
			}
			?>
		</table>
	</div>
</body>
</html>
