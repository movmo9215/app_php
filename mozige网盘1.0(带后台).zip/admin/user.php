<?php
	include('../install/db.php');//引入连接数据库需要的文件
	//验证账号信息
	session_start();
	$key=$_SESSION['admin_key'];
	if($key){
	}else{
		echo "<script>alert('鉴权错误')</script>";
		echo "<script>window.location.replace('../index.php')</script>";
	}





	//判断数据库是否连接
	try {
		$pdo = new PDO($dsn,$sql_user,$sql_pwd);
		// echo "数据库连接成功";
	} catch (Exception $e) {
		echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
		echo "<script>window.location.replace('install/index.html')</script>";
	}




	//查询用户信息
	try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
            $sql = "SELECT * FROM `pan_user`";//可在数据库复制
            $code=$pdo->query($sql);//预查询语句
            if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
             	$quer_user=$code->fetchAll();//遍历数据表
        }else{//否则
				echo "<script>alert('获取用户数据失败~')</script>";
        }
    }catch(PDOException $e){//异常处理
        echo "ERROR:".$e->getMessage();
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/medio.css">
	<script type="text/javascript" src="../js/index.js"></script>
	<script type="text/javascript" src="js/index.js"></script>
	<title>mozige网盘|后台</title>
</head>
<body>
	<!-- hend -->
	<div id="hend">
		<div id="bigmanu">
					<a class='toubin ' href='home.php' >主页</a>
					<a class='toubin ' href='file.php' >文件管理</a>
					<a class='toubin toubin_active' href='user.php' >用户管理</a>
					<a class='toubin ' href='config.php' >配置信息管理</a>
					<a class='toubin ' href='admin.php' >后台信息管理</a>
		</div>

		<div id="admin_smallmanu" class="admin_smallmanu">
					<div class='small_btn'><a href='home.php' target="top">主页</a></div>
					<hr>
					<div class='small_btn'><a href='file.php'>文件管理</a></div>
					<hr>
					<div class='small_btn'><a href='user.php'>用户管理</a></div>
					<hr>
					<div class='small_btn'><a href='config.php'>配置信息管理</a></div>
					<hr>
					<div class='small_btn'><a href='admin.php'>后台信息管理</a></div>
		</div>
		<div id="right_btn" class="right_btn" onclick="opensmall()">OPEN</div>
	</div>



	<div id="adminbox">
		<h1>数据分析:</h1>
		<?php
		try{
        $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据
		$sqluserall="SELECT COUNT(`id`) AS userall FROM `pan_user`";
        $codeall=$pdo->query($sqluserall);//预查询语句
        if($row = $codeall->fetch(PDO::FETCH_ASSOC)){
        	$uall=$row['userall'];
        	echo "<hr><h1>用户统计：[{$uall}]</h1>";
        }
	    }catch(PDOException $e){//异常处理
	        echo "ERROR:".$e->getMessage();
	    }
	    ?>
		<table>
			<tr>
				<td>用户名</td>
				<td>用户状态</td>
				<td>操作</td>
			</tr>
			<?php
			if($quer_user){
				foreach($quer_user as $quser){
					$id=$quser['ID'];
					$quser_=$quser['username'];
					$quinfo_=$quser['info'];
					if ($quinfo_==1) {
						$quinfo_pf="<span class='user_false'>异常</span>";
					}else{
						$quinfo_pf="<span class='user_true'>正常</span>";
					}
					echo "<tr>";
					echo "
								<th>{$quser_}</th>
								<th>{$quinfo_pf}</th>
						 ";
					echo "<th>";
					if($quinfo_==0){
						echo "[<a href='../comm/all.php?all=userinfo&userid={$id}&up=1'>改为封禁状态</a>]";
					}
					if($quinfo_==1){
						echo "[<a href='../comm/all.php?all=userinfo&userid={$id}&up=0'>改为正常状态</a>]";

					}
					echo "</th>";
					echo "</tr>";
				}
			}
			else{
				echo"<tr>
						<th>获取用户数据失败</th>
						<th>获取用户数据失败</th>
						<th>获取用户数据失败</th>
					 <tr>";
			}
			?>
		</table>
	</div>
</body>
</html>
