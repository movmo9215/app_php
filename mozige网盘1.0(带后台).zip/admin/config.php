<?php
	include('../install/db.php');//引入连接数据库需要的文件
	//验证账号信息
	session_start();
	$key=$_SESSION['admin_key'];
	if($key){
	}else{
		echo "<script>alert('鉴权错误')</script>";
		echo "<script>window.location.replace('../index.php')</script>";
	}





	//判断数据库是否连接
	try {
		$pdo = new PDO($dsn,$sql_user,$sql_pwd);
		// echo "数据库连接成功";
	} catch (Exception $e) {
		echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
		echo "<script>window.location.replace('install/index.html')</script>";
	}




	//查询文件数据信息
	try{
	    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
	        $sql = "SELECT * FROM `pan_config`";//可在数据库复制
	        $code=$pdo->query($sql);//预查询语句
	        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
	            $quer_config=$code->fetchAll();//遍历数据表
	    	}else{
				echo "<script>alert('获取文件数据失败~')</script>";
	    	}
	}catch(PDOException $e){//异常处理
	    echo "ERROR:".$e->getMessage();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/medio.css">
	<script type="text/javascript" src="../js/index.js"></script>
	<script type="text/javascript" src="js/index.js"></script>
	<title>mozige网盘|后台</title>
</head>
<body>
	<!-- hend -->
	<div id="hend">
		<div id="bigmanu">
					<a class='toubin ' href='home.php' >主页</a>
					<a class='toubin ' href='file.php' >文件管理</a>
					<a class='toubin ' href='user.php' >用户管理</a>
					<a class='toubin toubin_active' href='config.php' >配置信息管理</a>
					<a class='toubin ' href='admin.php' >后台信息管理</a>
		</div>

		<div id="admin_smallmanu" class="admin_smallmanu">
					<div class='small_btn'><a href='home.php' target="top">主页</a></div>
					<hr>
					<div class='small_btn'><a href='file.php'>文件管理</a></div>
					<hr>
					<div class='small_btn'><a href='user.php'>用户管理</a></div>
					<hr>
					<div class='small_btn'><a href='config.php'>配置信息管理</a></div>
					<hr>
					<div class='small_btn'><a href='admin.php'>后台信息管理</a></div>
		</div>
		<div id="right_btn" class="right_btn" onclick="opensmall()">OPEN</div>
	</div>



	<div id="adminbox">
		<table>
		<h1>配置信息设置</h1>
			<tr>
				<td>公告</td>
				<td>版本号</td>
			</tr>
			<?php
			if($quer_config){
				foreach($quer_config as $qconfig){
					$gogao=$qconfig['gogao'];//ID
					$banbenhao=$qconfig['banbenhao'];//用户名
					echo "
						<form action='../comm/all.php?all=config' method='post'>
						<tr>
						<th><textarea style='height:250px; width:100%;' name='gogao'>{$gogao}</textarea></th>
						<th><textarea style='height:250px; width:100%;' name='newbanbenhao'>{$banbenhao}</textarea></th>
						<input name='banbenhao' value='{$banbenhao}' style='display:none;'>
					 	<tr>
					 	<tr><th colspan='2'><button type='sumbit' class='btn right'>修改</button></th></tr>
						</form>
						 ";
				}
			}
			else{
				echo"<form action='../comm/all.php?all=config' method='post'>
						<tr>
						<th><textarea style='height:250px; width:100%;' name='gogao' placeholder='没有内容请填写后上传'></textarea></th>
						<th><textarea style='height:250px; width:100%;' name='newbanbenhao' placeholder='没有内容请填写后上传'></textarea></th>
						<input name='banbenhao' value='' style='display:none;'>
					 	<tr>
					 	<tr><th colspan='2'><button type='sumbit' class='btn right'>提交</button></th></tr>
						</form>";
			}
			?>
		</table>
	</div>
</body>
</html>
