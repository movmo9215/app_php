<?php
	include('../install/db.php');//引入连接数据库需要的文件
	//验证账号信息
	session_start();
	if($_SESSION['admin_key']!=""){
		echo "<script>window.location.replace('home.php')</script>";
	}else{
		echo "<script>alert('鉴权错误')</script>";
	}
	//判断数据库是否连接
	try {
		$pdo = new PDO($dsn,$sql_user,$sql_pwd);
		// echo "数据库连接成功";
	} catch (Exception $e) {
		echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
		echo "<script>window.location.replace('install/index.html')</script>";
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<script type="text/javascript" src="../js/index.js"></script>
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/medio.css">
	<title>mozige网盘|后台登录</title>
</head>
<body>
	<div style="margin-top: 200px;">
		<div class="box">
			<h1 class="center">mozige网盘|后台系统</h1>
			<form action='../comm/all.php?all=admin' method='post' onsubmit="return logins()">
				管理员账号<span style='color:red;'>*</span>：
				<br>
				<input class='input' type='text' name='admin_user' id="a">
				<br>
				管理员密码<span style='color:red;'>*</span>：
				<br>
				<input class='input' type='password' name='admin_pwd' id="b">
				管理员唯一凭证<span style='color:red;'>*</span>：
				<br>
				<input class='input' type='password' name='admin_key' id="d">
				<div id="c" style="color:red;" ></div>
				<div style="float: right;" >
					<button class='btn' type="submit">登录</button>
				</div>
			</form>
		</div>
	</div>	
</body>
</html>