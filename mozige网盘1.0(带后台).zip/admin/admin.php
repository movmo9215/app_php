<?php
	include('../install/db.php');//引入连接数据库需要的文件
	//验证账号信息
	session_start();
	$key=$_SESSION['admin_key'];
	if($key){
	}else{
		echo "<script>alert('鉴权错误')</script>";
		echo "<script>window.location.replace('../index.php')</script>";
	}





	//判断数据库是否连接
	try {
		$pdo = new PDO($dsn,$sql_user,$sql_pwd);
		// echo "数据库连接成功";
	} catch (Exception $e) {
		echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
		echo "<script>window.location.replace('install/index.html')</script>";
	}




	//查询文件数据信息
	try{
	    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
	        $sql = "SELECT * FROM `pan_admin`";//可在数据库复制
	        $code=$pdo->query($sql);//预查询语句
	        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
	            $admin=$code->fetchAll();//遍历数据表
	    	}else{
				echo "<script>alert('获取文件数据失败~')</script>";
	    	}
	}catch(PDOException $e){//异常处理
	    echo "ERROR:".$e->getMessage();
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/index.css">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="../css/medio.css">
	<script type="text/javascript" src="../js/index.js"></script>
	<script type="text/javascript" src="js/index.js"></script>
	<title>mozige网盘|后台</title>
</head>
<body>
	<!-- hend -->
	<div id="hend">
		<div id="bigmanu">
					<a class='toubin ' href='home.php' >主页</a>
					<a class='toubin ' href='file.php' >文件管理</a>
					<a class='toubin ' href='user.php' >用户管理</a>
					<a class='toubin ' href='config.php' >配置信息管理</a>
					<a class='toubin toubin_active' href='admin.php' >后台信息管理</a>
		</div>

				<div id="admin_smallmanu" class="admin_smallmanu">
					<div class='small_btn'><a href='home.php' target="top">主页</a></div>
					<hr>
					<div class='small_btn'><a href='file.php'>文件管理</a></div>
					<hr>
					<div class='small_btn'><a href='user.php'>用户管理</a></div>
					<hr>
					<div class='small_btn'><a href='config.php'>配置信息管理</a></div>
					<hr>
					<div class='small_btn'><a href='admin.php'>后台信息管理</a></div>
		</div>
		<div id="right_btn" class="right_btn" onclick="opensmall()">OPEN</div>
	</div>

	<div id="adminbox">
		<h1>后台信息管理</h1>
		<?php
		if($admin){
				foreach($admin as $admin_row){
					$ID=$admin_row['ID'];//ID
					echo "
					<div style='margin-top: 100px;'>
						<div class='box'>
						<h1>修改后台信息</h1>
							<form action='../comm/all.php?all=admin_xiugai' method='post' onsubmit='return logins()'>
								[修改]管理员账号<span style='color:red;'>*</span>：
								<br>
								<input class='input' type='text' name='adminuser' id='a'>
								<br>
								[修改]管理员密码<span style='color:red;'>*</span>：
								<br>
								<input class='input' type='text' name='adminpwd' id='b'>
								[修改]管理员唯一凭证<span style='color:red;'>*</span>：
								<br>
								<input class='input' type='text' name='adminkey' id='d'>
								<input class='input' type='text' name='adminID' id='d' value='{$ID}' style='display:none;'>
								<div id='c' style='color:red;' ></div>
								<div style='float: right;' >
									<button class='btn' type='submit'>修改</button>
								</div>
							</form>
						</div>
					</div>";
				}
		}else{
					echo"NULL";
			}
		?>
	</div>
</body>
</html>
