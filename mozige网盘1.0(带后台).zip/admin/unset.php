<?php 
session_start();//开启会话
unset($_SESSION['admin_key']);//释放会话变量
// session_unset();//关闭会话
echo "<script>alert('已安全退出~')</script>";
echo "<script>window.location.replace('index.php')</script>";
 ?>