<?php
include('install/db.php');//引入连接数据库需要的文件
//验证账号信息
session_start();
$username=$_SESSION['user'];
if($username){
}else{	
	echo "<script>alert('请登录')</script>";
	echo "<script>window.location.replace('login.php')</script>";
}
//判断数据库是否连接
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
//查询用户信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_user` WHERE `username`='{$username}'";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
         	$quer_user=$code->fetchAll();//遍历数据表
    }else{//否则
			echo "<script>alert('获取用户数据失败~')</script>";
    }
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>Mozige网盘|[<?php echo $username ?>]的个人信息</title>
</head>
<body>
	<!-- hend -->
		<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left' href='myfile.php'>我的文件</a>
					<a class='vh_10 left a_active' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>

	<div id="navter">
		<!-- 个人信息 -->
		<div class="box">
			<h1 style="text-align:center;" ><?php echo $username ?></h1>
			<br>
			<div  style="cursor: pointer;" class='center' onclick="openweb('upmima.php')" >修改密码</div>
			<br>
			<div  style="cursor: pointer;" class='center' onclick="openwebif('unset.php','确定要退出登录吗')" >退出登录</div>
			<br>
			<div  style="cursor: pointer;" class='center' onclick="openweb('about.php')" >关于本站</div>
			<br>
			<div  style="cursor: pointer;" class='center'>
				当前用户状态:
				<?php
				 if($quer_user){
				 	foreach($quer_user as $fig){
				 		$q=$fig['info'];
				 		if($q==0){
				 			echo "<span class='user_true'>正常</span>";
				 		}else{
				 			echo "<span class='user_false'>异常</span>";
				 		}
				 	}
				} 
				 ?>
			</div>
			<br>
			<?php
				 if($quer_user){
				 	foreach($quer_user as $fig){
				 		$q=$fig['info'];
				 		if($q==1){
				 			echo "<div class='center'>
							 			<span class='user_false'>
							 			温馨提示：您的账号疑似违法行为,已暂停使用部分功能，请联系站长解决,站长QQ:2039789716。
							 			</span>
						 		  </div>";
				 		}else{}
				 	}
				} 
			 ?>
			<div  style="cursor: pointer;" class='center'> 当前网盘版本:<?php if($config){foreach($config as $fig){echo $fig['banbenhao'];}}else{}?></div>
		</div>
	</div>	
	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>
	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
</body>
</html>