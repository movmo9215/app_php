<?php
include('install/db.php');//引入连接数据库需要的文件
//验证账号信息
session_start();
$username=$_SESSION['user'];
if($username){
}else{	
	echo "<script>alert('请登录')</script>";
	echo "<script>window.location.replace('login.php')</script>";
}
//判断数据库是否连接
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>Mozige网盘|[<?php echo $username ?>]的个人信息</title>
</head>
<body>
	<!-- hend -->
		<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left' href='myfile.php'>我的文件</a>
					<a class='vh_10 left a_active' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>

	<div id="navter">
		<!-- 个人信息 -->
		<div class="box">
			<h1 style="text-align:center; cursor: pointer;">关于本站</h1>
			<h2 style="text-align:center; cursor: pointer;">本站由网友 mozige 开发</h2>
			<h2 style="text-align:center; cursor: pointer;">网站会不定时更新,请留意下面版本号</h2>
			<h2 style="text-align:center; cursor: pointer;">[本站已接入两款免费图片API]</h2>
			<h3 style="text-align:center; cursor: pointer;">大屏幕API:<a href='https://imgapi.xl0408.top/index.php' target="_black">https://imgapi.xl0408.top/index.php</a></h3>
			<h3 style="text-align:center; cursor: pointer;">小屏幕API:<a href='https://api.ghser.com/random/pe.php' target="_black">https://api.ghser.com/random/pe.php</a></h3>
			<hr>
			<div href="" class='center'><h1><a class="btns" href="admin.php">返回</a></h1></div>
			<br>
			<h2 style="text-align:center;">感觉不错!那就赞一下吧~</h2>
			<div href="" class='center'><img src="img/kiss.jpg" class="about_img"></div>
			<br>
			<div href="" class='center'>当前网盘版本:<?php if($config){foreach($config as $fig){echo $fig['banbenhao'];}}else{}?></div>
		</div>
	</div>	
	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn end_btns' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>
	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
</body>
</html>