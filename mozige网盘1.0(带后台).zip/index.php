<?php
//计算文件大小
function trans_byte($byte)
{
    $KB = 1024;
    $MB = 1024 * $KB;
    $GB = 1024 * $MB;
    $TB = 1024 * $GB;
    if ($byte < $KB) {
        return $byte . "B";
    } elseif ($byte < $MB) {
        return round($byte / $KB, 2) . "KB";
    } elseif ($byte < $GB) {
        return round($byte / $MB, 2) . "MB";
    } elseif ($byte < $TB) {
        return round($byte / $GB, 2) . "GB";
    } else {
        return round($byte / $TB, 2) . "TB";
    }
}
include('install/db.php');//引入连接数据库需要的文件
session_start();
//验证账号信息
$username=$_SESSION['user'];
try {
	$pdo = new PDO($dsn,$sql_user,$sql_pwd);
	// echo "数据库连接成功";
} catch (Exception $e) {
	echo "<script>alert('无法连接数据库，请配置数据库信息')</script>";
	echo "<script>window.location.replace('install/index.php')</script>";
}
//查询文件数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `pan_file` WHERE `upinfo`=1";//可在数据库复制
        $code=$pdo->query($sql);//预查询语句
        if($code && $code->rowCount()){//执行查询语句 并且 查询到有数据时 
            $upname=$code->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
//查询基本配置数据信息
try{
    $pdo=new PDO($dsn,$sql_user,$sql_pwd);//生成PDO对象连接数据库
        $sqls = "SELECT * FROM `pan_config`";//可在数据库复制
        $codes=$pdo->query($sqls);//预查询语句
        if($codes && $codes->rowCount()){//执行查询语句 并且 查询到有数据时 
            $config=$codes->fetchAll();//遍历数据表
    	}else{
			// echo "<script>alert('获取文件数据失败~')</script>";
    	}
}catch(PDOException $e){//异常处理
    echo "ERROR:".$e->getMessage();
}
unset($pdo);
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/index.css">
	<link rel="stylesheet" type="text/css" href="css/medio.css">
	<script type="text/javascript" src="js/index.js"></script>
	<title>Mozige网盘|[主页]</title>
</head>
<body>
	<!-- hend -->
	<div id="hend">
		<div id="logo">
			<a href="index.php"><img src="img/logo.png" class="logo_img"></a>
		</div>
		<div id="bigmanu">
			<?php 
				if($username!=""){
					echo "
					<a class='vh_10 left' href='updatafile.php'>上传文件</a>
					<a class='vh_10 left' href='myfile.php'>我的文件</a>
					<a class='vh_10 left' href='admin.php'>{$username}</a>

					";
				}else{
					echo "<a class='vh_10 left' href='login.php'>登录</a>";
				}
			 ?>
		</div>
		 <a class="vh_10 right" id="gogao_btn" onclick="opengg()">公告</a>
	</div>
	<!-- 输出文件 -->
	<div id="navter">
		<div class="tablebox">	
		<table>
			<tr>
				<td colspan="10">公共文件夹</td>
			</tr>
			<tr>
				<td>用户名</td>
				<td>文件名</td>
				<td>上传时间</td>
				<?php 
					switch($username){
						case $username===$username:
						echo "<td>操作</td>";
						break;
					}
				?>
			</tr>
				<?php
				if($upname){//有数据就遍历数据
					foreach($upname as $up){
					$un=$up['user'];
					$uID=$up['ID'];
					$fname=$up['file_name'];
					$ftime=$up['file_time'];
					$fsize=trans_byte($up['file_size']);
					$ftype=$up['file_type'];
					switch($username){
					case $username===$username://有用户名验证信息时，就有查看权限
					echo "
					<tr>
						<th>{$un}	</th>
						<th>{$fname}</th>
						<th>{$ftime}</th>
						<th><div style='cursor: pointer;' onclick='openweb(&quot;see.php?seeid={$uID}&seename={$un}&quot;)'>查看</div></th>
						";
					break;
					case $username===""://没用户名验证信息时，就没查看权限
					echo "
						<th>{$un}	</th>
						<th>{$fname}</th>
						<th>{$ftime}</th>
					</tr>
						";
						}
					}
				}else{//木有数据就显示为空值
					echo "
						<th>NULL</th>
						<th>NULL</th>
						<th>NULL</th>
						";
					switch($username){
					case $username===$username://有用户名验证信息时，就有查看权限
					echo "
						<th>NULL</th>
					</tr>
						";
					case $username===""://没用户名验证信息时，就没查看权限
					echo "
					</tr>
						";
					}
				}
				?>
				<span style="color:red;" class="leftt">⬅左滑查看更多信息</span>
		</table>
		</div>
		<?php if($upname){}else{echo "<div class='guding' onclick='openweb(&quot;updatafile.php&quot;)' >👉似乎没有文件上传 (:</div>";} ?>
		<br>
		<?php if($username){}else{echo "<div class='guding' onclick='openweb(&quot;login.php&quot;)' >👉登录才能上传/下载文件哟</div>";} ?>
	</div>

	<div class="end1">--- Copyright&copy; Mozige 2023 | 友情链接 <a href="http://stakproject.top" target="_black">Mozige导航 </a>---</div>
	<div class="end2">
		<?php
		if ($username){
			echo"<div class='end_btn end_btns' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' onclick='openweb(&quot;updatafile.php&quot;)'>上传文件</div>
				 <div class='end_btn' onclick='openweb(&quot;myfile.php&quot;)'>我的文件</div>
				 <div class='end_btn' onclick='openweb(&quot;admin.php&quot;)'>个人信息</div>";
		}else{
			echo"<div class='end_btn end_btns' onclick='openweb(&quot;index.php&quot;)'>主页</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' >(无权限)</div>
				 <div class='end_btn' onclick='openweb(&quot;login.php&quot;)'>去登录</div>";
		}
		?>
	</div>

	<div id="gogao_nav" class="gogao_nav">
		<div class="center p-20">
			<div id="x" class='x' onclick="opengg()">❌</div>
			<h1>公告</h1>
			<h3>
				<?php
				 if($config){
				 	foreach($config as $fig){
				 		$gogao=$fig['gogao'];
				 		echo $gogao;
				 	}
				 }else{}
				?>
			</h3>
		</div>
	</div>
</body>
</html>