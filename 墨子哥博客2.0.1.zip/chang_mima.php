<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `user` WHERE `user`='{$users}'";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
           $rows=$code->fetchAll();
        }else{
            // echo "<script>alert('获取数据失败')</script>";
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
        $sql = "SELECT * FROM `about`";
        $code=$pdo->query("$sql");
        if($code && $code->rowCount()){
               $nr=$code->fetchAll();
        }
}catch(PDOException $e){//异常处理
    echo $e->getMessage().'<br>';
}
unset($pdo);//关闭连接
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/medio.css">
    <title>mozige博客</title>
</head>
<body>
    <!-- hend -->
    <div id="hend">
        <!-- logo -->
        <div id="logo">
            <a href="index.php">mozige博客</a>
        </div>
        <!-- nav -->
        <div id="nav">
            <ul>
                <li>
                    <?php 
                        if($users!=""){
                           
                        }else{
                            echo "<a href='login.php'>去登录/注册</a>";
                        }
                     ?>
                </li>
                <li>
                    <div type="checkbox" id="day_night" class="day_night" onclick="day_night()">sun</div>
                </li>
            </ul>
        </div>
        <!-- user -->
        <div id="user">
            <?php 
                if($users!=""){
                    foreach($rows as $row) {
                         echo "<a href='me.php'><img src='{$row['img']}' alt='' id='user_img'></a>";
                    };
                }else{
                     echo "请登录";
                }
             ?> 
        </div>
    </div>
    <!-- body -->
    <div id="body">
       
        <?php 
                if($users!=""){
                    echo "<div id='me_card'>
                                <form method='post'  action='chang_mima_sumbit.php'>
                                        <input type='text' name='chang_mima1' placeholder='新密码' class='logininput'>
                                        <br>
                                        <input type='text' name='chang_mima2' placeholder='二次确认密码' class='logininput'>
                                        <br>
                                        <br>
                                        <button type='submit' class='changhend_button' onclick='tp()'>修改</button>
                                         <p>注:修改密码后，会自动退出登录，请务必记住您的密码。</p>
                                </form>
                            </div>";
                        }else{
                            echo "<a href='login.php'>去登录/注册</a>";
                }
        ?>

    <!-- end -->
    <div id="end">
        <!-- copy -->
        <h4>本站由 <a href="https://www.youzai.tech" target="_blank">柚崽云虚拟主机</a> 提供相关技术支持</h4>
    </div>
</body>
    <script src="js/index.js"></script>
</html>