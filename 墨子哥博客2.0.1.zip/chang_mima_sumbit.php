<?php 
include('conn.php');
session_start();
$users=$_SESSION['user'];
$mima1=$_POST['chang_mima1'];
$mima2=$_POST['chang_mima2'];
if($mima1 != $mima2){
                echo "<script>alert('修改失败，请确认二次密码无误')</script>";
                echo"<script>window.location.replace('chang_mima.php');</script>";
                return false;
}
if($mima1==""){
                echo "<script>alert('不能为空')</script>";
                echo"<script>window.location.replace('chang_mima.php');</script>";
                return false;
}
if($mima2==""){
                echo "<script>alert('不能为空')</script>";
                echo"<script>window.location.replace('chang_mima.php');</script>";
                return false;
}
if($mima1=="" && $mima2==""){
                echo "<script>alert('不能为空')</script>";
                echo"<script>window.location.replace('chang_mima.php');</script>";
                return false;
}
else{
    try{
    $pdo=new PDO($dsn,$user,$pwd);//生成PDO对象连接数据库
            $sql="UPDATE `user` SET `pwd`='{$mima2}' WHERE `user`='{$users}'";
            $code=$pdo->exec("$sql");
            if($code>0){
                echo "<script>alert('密码修改成功')</script>";
                echo"<script>window.location.replace('unset.php');</script>";
            }else{
                echo "<script>alert('密码修改失败')</script>";
                echo"<script>window.location.replace('chang_mima.php');</script>";
            }
    }catch(PDOException $e){//异常处理
        echo $e->getMessage().'<br>';
    }
    unset($pdo);//关闭连接
}
?>